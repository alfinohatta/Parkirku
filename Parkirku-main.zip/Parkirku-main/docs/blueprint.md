# **App Name**: ParkRight

## Core Features:

- Manual Transaction Input: Enable manual input of vehicle plate numbers, type, and parking area upon entry.
- Automated Fee Calculation: Automatically calculate parking fees based on entry time, vehicle type, and hourly rates defined by the admin, adhering to maximum daily limits.
- Role-Based Access Control: Implement access control for Admin, Parking Attendant, and Owner roles, with specific permissions for configuration, operations, and monitoring.
- Parking Area Management: Allow admins to manage parking areas, including adding new areas and monitoring current capacity.
- Transaction Logging: Record all parking transactions with details such as entry time, exit time, duration, fee, and attending personnel into logs.
- Subscription Tracking: Admin tool to activate or expire user's subscription and give fee reduction. If membership expire and payment is skipped it's possible to drop membership to regular mode by switching boolean flag.
- Reporting Dashboard: Enable Owners to check the financial information or create their own statistic dashboard for their financial benefits by time or date.

## Style Guidelines:

- Primary color: Light lavender (#E6E6FA) to create a soothing atmosphere.
- Background color: Very light grey (#F5F5F5) to minimize eye strain during extended usage.
- Accent color: Pale violet red (#DDA0DD) to subtly highlight important actions and data.
- Body and headline font: 'PT Sans', a humanist sans-serif for a blend of modernity and approachability.
- Code font: 'Source Code Pro' for clear display of transaction codes.
- Employ a clear layout optimized for easy input of vehicle and financial data. The focus shall be given to an overview table on parking entries.
- Gentle transitions for user guidance and focus on data shown or table interaction.