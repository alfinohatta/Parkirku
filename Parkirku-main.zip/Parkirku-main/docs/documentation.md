# ParkRight - Program Documentation

## 1. Project Overview
**ParkRight** adalah sistem manajemen parkir modern berbasis web yang dirancang untuk mengelola operasional parkir secara manual namun terstruktur. Aplikasi ini memfasilitasi pencatatan kendaraan, perhitungan tarif otomatis berdasarkan durasi, manajemen langganan (member), integrasi pembayaran online (Stripe), hingga pelaporan keuangan yang mendalam bagi pemilik fasilitas.

*   **Kategori**: Manajemen Operasional / Enterprise Resource Planning (ERP) Sederhana.
*   **Target Pengguna**: Admin Sistem, Petugas Parkir (Attendant), dan Pemilik Fasilitas (Owner).

---

## 2. Features
Aplikasi ini memiliki fitur utama yang dibagi berdasarkan peran pengguna:

### **Umum**
*   **Role-Based Access Control (RBAC)**: Akses terbatas sesuai peran (Admin, Petugas, Owner).
*   **AI Assistant (Genkit)**: Asisten pintar untuk menjawab pertanyaan operasional dan memberikan wawasan data dalam bahasa natural.

### **Admin**
*   **Manajemen Pengguna**: CRUD data petugas dan admin.
*   **Manajemen Tarif**: Pengaturan tarif per jam, jam pertama, dan batas maksimum harian per jenis kendaraan.
*   **Manajemen Area**: Penentuan kapasitas dan monitoring okupansi area parkir.
*   **Subscription Tracking**: Pengelolaan data kendaraan member (aktif/kedaluwarsa).

### **Petugas (Attendant)**
*   **Check-In Manual**: Input plat nomor, jenis kendaraan, dan area parkir.
*   **Automated Fee Calculation**: Perhitungan biaya otomatis berdasarkan durasi parkir dan tipe kendaraan.
*   **Multi-Payment Support**: Mendukung Tunai, QRIS, Debit, Member, dan **Stripe (Online Card Payment)**.
*   **Receipt Printing**: Pencetakan struk transaksi otomatis setelah check-out.

### **Owner**
*   **Reporting Dashboard**: Visualisasi pendapatan, tren kendaraan, dan jam sibuk menggunakan grafik interaktif.
*   **Audit Log**: Rekam jejak seluruh aktivitas penting dalam sistem untuk transparansi.

---

## 3. System Architecture
Aplikasi dibangun dengan arsitektur **Single Page Application (SPA)** menggunakan framework Next.js.

*   **Frontend**: Next.js 15 (App Router), React 19, Tailwind CSS, ShadCN UI.
*   **State Management**: Persistent State (sinkronisasi otomatis dengan Browser LocalStorage) & React Hooks.
*   **Backend Services**: Next.js Server Actions untuk integrasi pihak ketiga.
*   **Integrasi Pihak Ketiga**:
    *   **Stripe**: Pemrosesan pembayaran kartu kredit/debit secara aman.
    *   **Firebase (Opsional/Planned)**: Infrastruktur untuk database real-time.
    *   **Genkit (Google Gemini)**: Mesin AI untuk analisis data.

---

## 4. Installation Guide
### Prerequisites
*   Node.js v20.x atau lebih baru.
*   npm atau yarn.

### Langkah Instalasi
1.  **Clone Repository**:
    ```bash
    git clone <repository-url>
    cd parkright
    ```
2.  **Install Dependencies**:
    ```bash
    npm install
    ```
3.  **Setup Environment Variables**:
    Buat file `.env` di root direktori:
    ```env
    # Stripe Keys
    NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
    STRIPE_SECRET_KEY=sk_test_...

    # AI Config
    GOOGLE_GENAI_API_KEY=your_api_key_here
    ```
4.  **Run Development Server**:
    ```bash
    npm run dev
    ```
    Aplikasi dapat diakses di `http://localhost:9002`.

---

## 5. Usage Instructions
1.  **Login**: Gunakan kredensial default (lihat `credential.md`).
2.  **Admin**: Masuk ke Tab "System Management" untuk mengatur tarif dan area parkir sebelum memulai operasional.
3.  **Petugas**: 
    *   Klik "New Check-In" saat kendaraan masuk.
    *   Cari plat nomor atau klik "Check Out" pada daftar kendaraan parkir saat kendaraan keluar.
    *   Pilih metode pembayaran dan cetak struk.
4.  **Owner**: Pantau grafik di dashboard untuk melihat performa harian. Gunakan "AI Assistant" untuk bertanya tentang pendapatan atau jam sibuk.

---

## 6. API Documentation
Aplikasi ini menggunakan Server Actions untuk komunikasi backend:

### **Stripe Integration**
*   **`createPaymentIntent(amount: number)`**
    *   **Purpose**: Membuat sesi pembayaran Stripe.
    *   **Input**: Jumlah biaya dalam IDR.
    *   **Output**: `clientSecret` untuk digunakan oleh Stripe Elements di frontend.

### **AI Integration**
*   **`getParkingInsights(input)`**: Memberikan analisis data keuangan untuk Owner.
*   **`getDailyOpsInsight(input)`**: Memberikan update operasional harian untuk Admin/Petugas.

---

## 7. Database Schema
Data saat ini dikelola secara persisten di `localStorage` dengan skema objek sebagai berikut:

| Entity | Fields | Description |
| :--- | :--- | :--- |
| **User** | id, nama, username, role, status | Data personil sistem. |
| **Vehicle** | id, plat_nomor, jenis, pemilik, warna | Master data kendaraan. |
| **Tariff** | id, jenis, tarif_awal, tarif_perjam, max | Konfigurasi biaya parkir. |
| **Area** | id, nama, kapasitas, terisi | Lokasi parkir fisik. |
| **Transaction** | id, id_kendaraan, masuk, keluar, biaya, status | Rekaman parkir. |
| **Subscription** | id, plat_nomor, aktif, tgl_berakhir | Data member parkir. |

---

## 8. Configuration
Konfigurasi utama terdapat pada:
*   `src/lib/data.ts`: Berisi data awal (mock data) untuk testing.
*   `tailwind.config.ts`: Konfigurasi tema warna Lavender & Violet.
*   `next.config.ts`: Pengaturan domain gambar dan optimasi build.

---

## 9. Testing
*   **Manual Testing**: 
    *   Lakukan siklus Check-In dan Check-Out untuk memastikan biaya terhitung benar.
    *   Gunakan kartu tes Stripe `4242 4242 4242 4242` untuk menguji pembayaran online.
*   **Validation Testing**: 
    *   Coba masukkan username > 20 karakter di form login untuk memastikan batas `maxLength` berfungsi.
*   **Responsiveness**: 
    *   Uji tampilan pada perangkat mobile menggunakan fitur "Inspect Element" di browser.

---

## 10. Deployment
Aplikasi ini dapat di-deploy ke platform seperti **Vercel** atau **Firebase App Hosting**:
1.  Pastikan semua Environment Variables sudah didaftarkan di dashboard platform deployment.
2.  Jalankan `npm run build` untuk memvalidasi tidak ada error TypeScript.
3.  Push kode ke branch utama (main) untuk trigger auto-deployment.

---

## 11. Contributing
1.  Fork repository.
2.  Buat fitur branch (`git checkout -b feature/AmazingFeature`).
3.  Commit perubahan (`git commit -m 'Add some AmazingFeature'`).
4.  Push ke branch (`git push origin feature/AmazingFeature`).
5.  Buka Pull Request.

---

## 12. License
Distributed under the MIT License. See `LICENSE` for more information.

---
© 2024 ParkRight Team. All rights reserved.