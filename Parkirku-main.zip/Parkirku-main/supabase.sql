-- ParkRight Supabase/PostgreSQL Reference Schema
-- This file contains the SQL definitions for all tables used in the ParkRight application.
-- It is designed to be compatible with PostgreSQL and can be used as a reference for database migration.

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS "tb_user";
CREATE TABLE "tb_user" (
  "id_user" SERIAL PRIMARY KEY,
  "nama_lengkap" VARCHAR(255) NOT NULL,
  "username" VARCHAR(100) UNIQUE NOT NULL,
  "password_hash" VARCHAR(255) NOT NULL,
  "role" VARCHAR(20) CHECK (role IN ('Admin', 'Petugas', 'Owner')) NOT NULL,
  "status_aktif" BOOLEAN DEFAULT TRUE
);

COMMENT ON COLUMN "tb_user"."role" IS 'User role: Admin, Petugas, Owner';

-- ----------------------------
-- Table structure for tb_tarif
-- ----------------------------
DROP TABLE IF EXISTS "tb_tarif";
CREATE TABLE "tb_tarif" (
  "id_tarif" SERIAL PRIMARY KEY,
  "jenis_kendaraan" VARCHAR(50) UNIQUE NOT NULL,
  "tarif_jam_pertama" DECIMAL(10, 0) NOT NULL,
  "tarif_per_jam" DECIMAL(10, 0) NOT NULL,
  "tarif_maks_harian" DECIMAL(10, 0) NOT NULL
);

-- ----------------------------
-- Table structure for tb_kendaraan
-- ----------------------------
DROP TABLE IF EXISTS "tb_kendaraan";
CREATE TABLE "tb_kendaraan" (
  "id_kendaraan" SERIAL PRIMARY KEY,
  "plat_nomor" VARCHAR(20) UNIQUE NOT NULL,
  "jenis_kendaraan" VARCHAR(50) NOT NULL,
  "pemilik" VARCHAR(255),
  "warna" VARCHAR(50)
);

-- ----------------------------
-- Table structure for tb_area_parkir
-- ----------------------------
DROP TABLE IF EXISTS "tb_area_parkir";
CREATE TABLE "tb_area_parkir" (
  "id_area" SERIAL PRIMARY KEY,
  "nama_area" VARCHAR(100) UNIQUE NOT NULL,
  "kapasitas" INT NOT NULL,
  "terisi" INT NOT NULL DEFAULT 0
);

-- ----------------------------
-- Table structure for tb_member (Subscriptions)
-- ----------------------------
DROP TABLE IF EXISTS "tb_member";
CREATE TABLE "tb_member" (
  "id" SERIAL PRIMARY KEY,
  "plat_nomor" VARCHAR(20) UNIQUE NOT NULL,
  "jenis_kendaraan" VARCHAR(50) NOT NULL,
  "tanggal_aktivasi" DATE NOT NULL,
  "tanggal_berakhir" DATE NOT NULL,
  "aktif" BOOLEAN NOT NULL
);

-- ----------------------------
-- Table structure for tb_transaksi
-- ----------------------------
DROP TABLE IF EXISTS "tb_transaksi";
CREATE TABLE "tb_transaksi" (
  "id_parkir" SERIAL PRIMARY KEY,
  "id_kendaraan" INT NOT NULL,
  "waktu_masuk" TIMESTAMPTZ NOT NULL,
  "waktu_keluar" TIMESTAMPTZ,
  "id_tarif" INT NOT NULL,
  "id_area" INT NOT NULL,
  "status" VARCHAR(20) CHECK (status IN ('di_dalam', 'selesai', 'dibatalkan')) NOT NULL,
  "id_petugas_masuk" INT NOT NULL,
  "id_petugas_keluar" INT,
  "durasi_jam" INT,
  "biaya_total" DECIMAL(10, 0),
  "metode_pembayaran" VARCHAR(20) CHECK (metode_pembayaran IN ('tunai', 'qris', 'debit', 'member', 'override')),
  "alasan_override" TEXT,
  FOREIGN KEY ("id_kendaraan") REFERENCES "tb_kendaraan"("id_kendaraan"),
  FOREIGN KEY ("id_tarif") REFERENCES "tb_tarif"("id_tarif"),
  FOREIGN KEY ("id_area") REFERENCES "tb_area_parkir"("id_area"),
  FOREIGN KEY ("id_petugas_masuk") REFERENCES "tb_user"("id_user"),
  FOREIGN KEY ("id_petugas_keluar") REFERENCES "tb_user"("id_user")
);

-- ----------------------------
-- Table structure for tb_log_aktivitas
-- ----------------------------
DROP TABLE IF EXISTS "tb_log_aktivitas";
CREATE TABLE "tb_log_aktivitas" (
  "id_log" SERIAL PRIMARY KEY,
  "id_user" INT NOT NULL,
  "aktivitas" TEXT NOT NULL,
  "waktu_aktivitas" TIMESTAMPTZ NOT NULL,
  FOREIGN KEY ("id_user") REFERENCES "tb_user"("id_user")
);


-- ----------------------------
-- Initial Data Insertion
-- ----------------------------

-- Note: Passwords should be properly hashed in a real application.
-- Using 'password123' as a placeholder hash.
INSERT INTO "tb_user" ("nama_lengkap", "username", "password_hash", "role") VALUES
('Admin ParkRight', 'admin', 'password123', 'Admin'),
('Budi Petugas', 'petugas1', 'password123', 'Petugas'),
('John Doe', 'owner', 'password123', 'Owner'),
('Siti Petugas', 'petugas2', 'password123', 'Petugas');

INSERT INTO "tb_tarif" ("jenis_kendaraan", "tarif_jam_pertama", "tarif_per_jam", "tarif_maks_harian") VALUES
('Motor', 2000, 1000, 8000),
('Mobil', 5000, 3000, 25000),
('Mobil Box', 8000, 5000, 50000),
('Valet', 50000, 0, 50000);

INSERT INTO "tb_area_parkir" ("nama_area", "kapasitas", "terisi") VALUES
('Basement 1', 50, 0),
('Area Terbuka A', 100, 0),
('Gedung Parkir Lt. 3', 75, 0);

-- Example vehicle insertion (optional)
INSERT INTO "tb_kendaraan" ("plat_nomor", "jenis_kendaraan", "pemilik", "warna") VALUES
('B 1234 ABC', 'Mobil', 'John Doe', 'Hitam'),
('D 5678 XYZ', 'Motor', 'Jane Smith', 'Merah');

-- Example member insertion (optional)
INSERT INTO "tb_member" ("plat_nomor", "jenis_kendaraan", "tanggal_aktivasi", "tanggal_berakhir", "aktif") VALUES
('F 9101 GHI', 'Mobil', '2024-07-01', '2024-07-31', true);
