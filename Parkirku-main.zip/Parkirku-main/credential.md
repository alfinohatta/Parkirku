# ParkRight Credentials

This file contains the login credentials for the default users in the application.

| Username   | Password      | Role    |
|------------|---------------|---------|
| `admin`    | `password123` | Admin   |
| `petugas1` | `password123` | Petugas |
| `owner`    | `password123` | Owner   |
| `petugas2` | `password123` | Petugas |
