# Dokumentasi Teknis per Modul - ParkRight

Dokumen ini memberikan rincian teknis untuk setiap modul fungsional dalam aplikasi ParkRight. Setiap modul dipecah menjadi proses-proses utama, dengan penjelasan mengenai **Input**, **Proses** (termasuk fungsi/metode yang relevan), dan **Output**.

## 1. Modul Otentikasi Pengguna

Modul ini menangani bagaimana pengguna masuk dan keluar dari sistem.

### Proses: Login Pengguna
- **File Terkait**: `src/app/login/page.tsx`
- **Deskripsi**: Memvalidasi kredensial pengguna dan membuat sesi di sisi klien.

- **Input**:
    - Pengguna memasukkan `username` dan `password` pada form login.
    - Pengguna menekan tombol "Login".

- **Proses**:
    1.  Form dikelola oleh `react-hook-form` dan divalidasi menggunakan skema dari `zod` (`loginSchema`).
    2.  Fungsi `handleLogin` dipanggil saat form disubmit.
    3.  Fungsi ini mencari data pengguna di dalam array `mockUsers` yang username dan `password_hash`-nya cocok dengan input.
    4.  Jika pengguna ditemukan, data pengguna (`user`) disimpan sebagai string JSON ke dalam `localStorage` dengan kunci `currentUser`.
    5.  Sebuah notifikasi "Login Successful" (`toast`) ditampilkan.
    6.  Pengguna diarahkan ke halaman utama (`/`) menggunakan `next/navigation` `router`.
    7.  Jika tidak ditemukan, `toast` error ditampilkan.

- **Output**:
    - Sesi pengguna dibuat di `localStorage`.
    - Pengguna diarahkan ke halaman dashboard yang sesuai dengan perannya (`Admin`, `Petugas`, atau `Owner`).

---

## 2. Modul Manajemen Data (Admin)

Modul ini hanya dapat diakses oleh `Admin` dan digunakan untuk mengelola data master sistem.

### Proses: CRUD (Create, Read, Update, Delete) Pengguna
- **File Terkait**: `src/components/dashboard/admin-dashboard.tsx`
- **Deskripsi**: Mengelola data pengguna sistem.

- **Input**:
    - Admin menekan tombol "Add New User", "Edit" (ikon pensil), atau "Delete" (ikon tong sampah).
    - Admin mengisi data pada form dialog yang muncul.

- **Proses**:
    1.  **State Management**: State `users` dikelola oleh custom hook `usePersistentState`, yang menyinkronkan data dengan `localStorage`.
    2.  **Create/Update**: Fungsi `handleSaveUser` dipanggil saat form dialog disubmit.
        - Jika `editingUser` ada, fungsi akan memperbarui data pengguna yang ada di dalam state `users`.
        - Jika tidak, fungsi akan membuat `id_user` baru dan menambahkan pengguna baru ke state `users`.
        - Form divalidasi menggunakan `userSchema` (Zod).
    3.  **Delete**: Fungsi `handleDeleteUser` dipanggil dari dialog konfirmasi.
        - Fungsi ini memfilter array `users` untuk menghapus pengguna dengan `id_user` yang dipilih.
    4.  **Logging**: Setiap aksi (tambah, edit, hapus) dicatat menggunakan fungsi `addLog` yang menambahkan entri baru ke state `activityLogs`.

- **Output**:
    - State `users` (dan `localStorage`) diperbarui.
    - Tabel pengguna di UI diperbarui secara reaktif.
    - Notifikasi `toast` ditampilkan untuk mengonfirmasi aksi.
    - Entri log aktivitas baru ditambahkan.

### Proses: CRUD Tarif Parkir
- **File Terkait**: `src/components/dashboard/admin-dashboard.tsx`
- **Deskripsi**: Mengelola tarif parkir untuk berbagai jenis kendaraan.

- **Input**:
    - Aksi Admin pada tombol "Add New Tariff", "Edit", atau "Delete".
    - Data dari form dialog tarif.

- **Proses**:
    1.  **State Management**: State `tariffs` dikelola oleh `usePersistentState`.
    2.  **Create/Update**: Fungsi `handleSaveTariff` menangani penyimpanan data baru atau pembaruan data yang sudah ada. Form divalidasi dengan `tariffSchema`.
    3.  **Delete**: Fungsi `handleDeleteTariff`. Terdapat logika penting di dalamnya:
        - Fungsi `openDeleteTariffDialog` memeriksa apakah `id_tarif` yang akan dihapus pernah digunakan di `transactions`.
        - Jika pernah, penghapusan dibatalkan dan `toast` error ditampilkan untuk menjaga integritas data.
        - Jika tidak, tarif akan dihapus dari state `tariffs`.
    4.  **Logging**: Aktivitas dicatat menggunakan `addLog`.

- **Output**:
    - State `tariffs` diperbarui.
    - UI dan `localStorage` diperbarui.
    - Karena tarif bersifat dinamis, semua dropdown pemilihan jenis kendaraan di seluruh aplikasi (misalnya di form check-in dan form langganan) akan otomatis menampilkan daftar tarif terbaru.

---

## 3. Modul Transaksi Parkir (Petugas)

Modul inti yang digunakan oleh `Petugas` untuk operasional harian.

### Proses: Kendaraan Masuk (Check-In)
- **File Terkait**: `src/components/dashboard/petugas-dashboard.tsx`
- **Deskripsi**: Mencatat kendaraan baru yang masuk ke area parkir.

- **Input**:
    - Petugas mengisi form "New Vehicle Check-In" (Plat Nomor, Jenis Kendaraan, Area Parkir, dll.).
    - Petugas menekan tombol "Confirm Check-In".

- **Proses**:
    1.  Fungsi `handleCheckIn` dipanggil.
    2.  **Validasi**:
        - Memastikan input tidak kosong.
        - Memeriksa apakah kendaraan dengan plat nomor yang sama sudah berstatus `di_dalam`.
        - Memeriksa apakah `terisi` pada `ParkingArea` yang dipilih sudah mencapai `kapasitas`.
    3.  **Data Kendaraan**:
        - Sistem mencari `Vehicle` di state `vehicles`. Jika tidak ada, entri `Vehicle` baru dibuat. Jika ada, data pemilik/warna diperbarui.
    4.  **Buat Transaksi**:
        - Entri baru dibuat di state `transactions` dengan `status: 'di_dalam'`, `waktu_masuk` saat ini, dan `id_petugas_masuk` diisi dengan ID petugas yang sedang login.
    5.  **Update Area**: Kolom `terisi` pada `ParkingArea` yang dipilih di-increment (`+1`).
    6.  **Logging**: Aktivitas dicatat melalui `addLog`.

- **Output**:
    - Transaksi baru tersimpan di state `transactions`.
    - Data `vehicles` dan `areas` diperbarui.
    - `localStorage` diperbarui untuk persistensi data.
    - Notifikasi `toast` sukses ditampilkan.
    - Tabel "Currently Parked Vehicles" di-update secara real-time.

### Proses: Kendaraan Keluar (Check-Out)
- **File Terkait**: `src/components/dashboard/petugas-dashboard.tsx`, `src/lib/utils.ts`
- **Deskripsi**: Menyelesaikan transaksi parkir, menghitung biaya, dan mencetak struk.

- **Input**:
    - Petugas mencari transaksi menggunakan Plat Nomor atau ID Transaksi.
    - Petugas menekan tombol "Check Out" pada salah satu kendaraan yang parkir.
    - Petugas memilih metode pembayaran di dialog konfirmasi.

- **Proses**:
    1.  Fungsi `handleSearchTransaction` atau klik tombol "Check Out" memicu fungsi `openCheckOutDialog`.
    2.  **Kalkulasi Biaya**:
        - `openCheckOutDialog` memanggil fungsi `calculateFee` dari `src/lib/utils.ts`.
        - **`calculateFee(transaction, tariffs, isMember)`**:
            - Menghitung durasi dalam menit antara `waktu_masuk` dan `waktu_keluar` (saat ini).
            - Menerapkan *grace period* 5 menit.
            - Mengonversi durasi menit ke jam, dibulatkan ke atas (`Math.ceil`).
            - Jika `isMember` true, biaya menjadi Rp 0.
            - Jika bukan member, biaya dihitung: `tarif_jam_pertama + ((durasi_jam - 1) * tarif_per_jam)`.
            - Menerapkan batas `tarif_maks_harian` jika total biaya melebihi batas tersebut.
            - Mengembalikan `{ totalFee, durationHours }`.
    3.  Hasil kalkulasi ditampilkan di dialog "Confirm Check-Out".
    4.  **Konfirmasi Pembayaran**:
        - Petugas menekan tombol metode pembayaran (`Pay Cash`, `Pay QRIS`, dll.), yang memanggil `handleCheckOut(paymentMethod)`.
        - Fungsi `processCheckout` dipanggil untuk finalisasi.
    5.  **Finalisasi Transaksi**:
        - `processCheckout` memperbarui entri di `transactions`: `status` diubah menjadi `'selesai'`, `waktu_keluar` diisi, begitu juga dengan `biaya_total`, `durasi_jam`, `metode_pembayaran`, dan `id_petugas_keluar`.
        - Kolom `terisi` pada `ParkingArea` di-decrement (`-1`).
    6.  **Force Checkout**: Jika petugas memilih "Force Checkout", fungsi `handleForceCheckout` akan mengisi `biaya_total` dengan 0 dan menyimpan `alasan_override`.
    7.  **Logging**: Aktivitas dicatat melalui `addLog`.

- **Output**:
    - Status transaksi diperbarui menjadi 'selesai'.
    - Kapasitas area parkir diperbarui.
    - `localStorage` di-update.
    - Dialog struk (`#receipt-content`) ditampilkan dengan detail transaksi untuk dicetak.

---

## 4. Modul Laporan & Analisis (Owner)

Modul ini hanya dapat diakses oleh `Owner` untuk memantau kinerja bisnis.

### Proses: Visualisasi Data dengan Filter Tanggal
- **File Terkait**: `src/components/dashboard/owner-dashboard.tsx`
- **Deskripsi**: Menampilkan metrik kunci dan visualisasi data berdasarkan rentang tanggal yang dipilih.

- **Input**:
    - Owner memilih rentang tanggal pada komponen `Calendar` (Date Range Picker).

- **Proses**:
    1.  **State & Filtering**:
        - State `date` menyimpan rentang tanggal yang dipilih.
        - `useMemo` digunakan untuk membuat `filteredTransactions` yang bergantung pada `date` dan `transactions`.
        - Logika filter memastikan hanya transaksi dengan `status: 'selesai'` yang `waktu_keluar`-nya berada dalam rentang tanggal yang dipilih yang akan diproses.
    2.  **Agregasi Data**:
        - `totalRevenue`, `totalVehicles`, dan `avgDuration` dihitung dari `filteredTransactions` menggunakan metode `reduce`.
    3.  **Data untuk Chart**:
        - `revenueByDay`, `vehicleMixData`, dan `peakHoursData` juga dihitung dari `filteredTransactions` menggunakan `useMemo` untuk efisiensi. Data ini diagregasi (dikelompokkan per hari, per jenis kendaraan, atau per jam) untuk diumpankan ke komponen *chart*.
    4.  **Rendering**:
        - Komponen dari `recharts` (`BarChart`, `PieChart`, `LineChart`) me-render data yang sudah diagregasi.

- **Output**:
    - Kartu KPI (Total Revenue, Vehicles Processed, Avg Duration) menampilkan data agregat.
    - *Chart* menampilkan visualisasi tren pendapatan, komposisi kendaraan, dan jam sibuk.
    - Tabel detail transaksi di bagian bawah juga hanya menampilkan data dari `filteredTransactions`.

---

## 5. Modul Asisten AI

Fitur ini tersedia untuk semua peran dengan konteks dan tujuan yang berbeda.

### Proses: Mendapatkan Insight (Umum)
- **File Terkait**: `src/ai/flows/*`, `src/components/dashboard/*-dashboard.tsx`
- **Deskripsi**: Mengajukan pertanyaan dalam bahasa natural untuk mendapatkan analisis dari data yang relevan.

- **Input**:
    - Pengguna mengetik pertanyaan di `Textarea` pada kartu "AI Assistant".
    - Pengguna menekan tombol "Ask AI".

- **Proses**:
    1.  Fungsi `handleAskAi` di masing-masing *dashboard* dipanggil.
    2.  **Persiapan Konteks**:
        - Fungsi ini mengumpulkan data relevan sesuai peran. Contoh untuk Owner: `filteredTransactions`, `vehicles`, dan `dateRange`. Contoh untuk Petugas: `todayTransactions`, `users`, `parkingAreas`.
        - Data ini diubah menjadi format string JSON.
    3.  **Memanggil AI Flow**:
        - Fungsi memanggil *server function* yang sesuai (`getParkingInsights` untuk Owner, `getDailyOpsInsight` untuk Admin/Petugas).
        - *Server function* ini berada di `src/ai/flows/`.
    4.  **Eksekusi Genkit**:
        - *Flow* yang relevan di Genkit (`parkingInsightsFlow` atau `dailyOpsFlow`) dieksekusi.
        - *Flow* ini meneruskan input (pertanyaan dan konteks data JSON) ke *prompt* yang sudah didefinisikan (`parkingInsightsPrompt` atau `dailyOpsPrompt`).
        - *Prompt* ini menginstruksikan model AI (LLM) untuk bertindak sebagai asisten dan menjawab pertanyaan berdasarkan data JSON yang diberikan.
    5.  Hasil teks dari LLM dikembalikan ke klien.

- **Output**:
    - Jawaban dari AI ditampilkan dalam format teks di bawah area input pada kartu "AI Assistant".