# ParkRight - Project Documentation

This document provides a comprehensive overview of the ParkRight project, its structure, the technologies used, and instructions for local development.

## 1. Project Overview

*   **Project Name**: ParkRight
*   **Category**: Web Application / Parking Management System
*   **Description**: A modern, role-based application designed for efficient manual parking management. It allows parking attendants to manage vehicle check-ins and check-outs, admins to configure system settings (like tariffs, users, and parking areas), and owners to monitor financial and operational performance through an analytical dashboard.

## 2. Technology Stack

The project is built with a modern, component-based, and type-safe technology stack.

*   **Framework**: [Next.js](https://nextjs.org/) (with App Router)
*   **Language**: [TypeScript](https://www.typescriptlang.org/)
*   **UI Library**: [React](https://reactjs.org/)
*   **Styling**: [Tailwind CSS](https://tailwindcss.com/)
*   **UI Components**: [ShadCN/UI](https://ui.shadcn.com/) - A collection of beautifully designed, accessible, and reusable components.
*   **Icons**: [Lucide React](https://lucide.dev/guide/packages/lucide-react)
*   **Charts & Data Visualization**: [Recharts](https://recharts.org/)
*   **Form Management**: [React Hook Form](https://react-hook-form.com/)
*   **Schema Validation**: [Zod](https://zod.dev/)

## 3. Project Structure

The project follows a standard Next.js App Router structure. Key directories include:

```
.
├── src
│   ├── app/                # Main application routes (pages) and layouts.
│   │   ├── login/          # Login page route
│   │   ├── layout.tsx      # Root layout for the entire application
│   │   └── page.tsx        # Home page, which routes to the correct dashboard
│   │
│   ├── components/         # Reusable React components.
│   │   ├── dashboard/      # Components specific to each user dashboard (Admin, Petugas, Owner)
│   │   ├── layout/         # Layout components like Header, Footer, and User Navigation
│   │   └── ui/             # Core UI components from ShadCN (Button, Card, Table, etc.)
│   │
│   ├── hooks/              # Custom React hooks (e.g., use-real-time, use-toast).
│   │
│   ├── lib/                # Utility functions, data types, and mock data.
│   │   ├── data.ts         # Mock data for users, transactions, etc., for development.
│   │   ├── types.ts        # TypeScript type definitions for the application's data models.
│   │   └── utils.ts        # General utility functions (e.g., `cn` for classnames, `calculateFee`).
│   │
│   └── public/             # Static assets like images and fonts.
│
├── credential.md           # Default user login credentials for testing.
├── README.md               # The original business requirements and blueprint.
└── structure.md            # This file.
```

## 4. Local Development

Follow these steps to set up and run the project on your local machine.

### Prerequisites

*   [Node.js](https://nodejs.org/) (version 20.x or later)
*   [npm](https://www.npmjs.com/) (usually comes with Node.js)

### Installation

1.  **Clone the repository**:
    ```bash
    git clone <your-repository-url>
    cd <project-directory>
    ```

2.  **Install dependencies**:
    Run the following command in the project's root directory to install all the necessary packages.
    ```bash
    npm install
    ```

### Running the Project

1.  **Start the development server**:
    To run the application in development mode, use the following command:
    ```bash
    npm run dev
    ```

2.  **Open the application**:
    The application will typically be available at **http://localhost:9002**. Open this URL in your web browser.

    The application will automatically reload if you make any changes to the code.

### Default Credentials

You can find the default login credentials for different user roles in the `credential.md` file. This allows you to test the functionality for Admins, Petugas (Attendants), and Owners.
