'use client';

import { useState, useEffect, Dispatch, SetStateAction } from 'react';

/**
 * Custom hook untuk menyimpan state secara persisten di localStorage.
 * Dirancang untuk menghindari kesalahan hidrasi di Next.js dengan memuat data setelah mount.
 */
function usePersistentState<T>(key: string, initialValue: T): [T, Dispatch<SetStateAction<T>>] {
  const [state, setState] = useState<T>(initialValue);
  const [isLoaded, setIsLoaded] = useState(false);

  // Muat data dari localStorage hanya setelah komponen terpasang (client-side)
  useEffect(() => {
    try {
      const item = window.localStorage.getItem(key);
      if (item) {
        setState(JSON.parse(item));
      } else {
        // Jika belum ada data, simpan initialValue ke storage
        window.localStorage.setItem(key, JSON.stringify(initialValue));
      }
    } catch (error) {
      console.error(`Error reading localStorage key “${key}”:`, error);
    }
    setIsLoaded(true);
  }, [key, initialValue]);

  // Simpan ke localStorage setiap kali state berubah, tapi hanya setelah data awal dimuat
  useEffect(() => {
    if (!isLoaded) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(state));
    } catch (error) {
      console.error(`Error setting localStorage key “${key}”:`, error);
    }
  }, [key, state, isLoaded]);

  return [state, setState];
}

export default usePersistentState;
