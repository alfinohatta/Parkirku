import { z } from 'zod';

// Define the input schema, which includes the user's question and the data context.
export const ParkingInsightsInputSchema = z.object({
  question: z.string().describe("The owner's question about the parking data."),
  transactions: z.string().describe('A JSON string of the transaction data for context.'),
  vehicles: z.string().describe('A JSON string of the vehicle data for context.'),
  dateRange: z.object({
      from: z.string().describe('The start date of the reporting period.'),
      to: z.string().describe('The end date of the reporting period.'),
  }).describe('The date range for the provided data.'),
});
export type ParkingInsightsInput = z.infer<typeof ParkingInsightsInputSchema>;


// New schema for Daily Operations Assistant
export const DailyOpsInputSchema = z.object({
  question: z.string().describe("The user's (admin/petugas) question about daily operations."),
  todayTransactions: z.string().describe('A JSON string of transaction data for the current day.'),
  users: z.string().describe('A JSON string of all user data.'),
  parkingAreas: z.string().describe('A JSON string of all parking area data.'),
  currentUser: z.string().describe('A JSON string of the currently logged-in user.'),
});
export type DailyOpsInput = z.infer<typeof DailyOpsInputSchema>;
