'use server';
/**
 * @fileOverview An AI flow for providing insights on parking data for the owner.
 *
 * - getParkingInsights - A function that answers questions about parking data.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { ParkingInsightsInputSchema, type ParkingInsightsInput } from '@/ai/types';

// The output is a simple string.
const ParkingInsightsOutputSchema = z.string();
type ParkingInsightsOutput = z.infer<typeof ParkingInsightsOutputSchema>;

// The main function that will be called from the frontend.
export async function getParkingInsights(input: ParkingInsightsInput): Promise<string> {
  return parkingInsightsFlow(input);
}

// Define the Genkit Prompt
const parkingInsightsPrompt = ai.definePrompt({
  name: 'parkingInsightsPrompt',
  input: { schema: ParkingInsightsInputSchema },
  output: { format: 'text' }, // The output is just plain text.
  prompt: `You are a helpful Decision Support Bot for a parking system owner.
Your goal is to answer questions and provide simple, clear insights based on the provided data.
The user is the owner of the parking facility. Be concise and professional.

The data is for the period from {{dateRange.from}} to {{dateRange.to}}.

Here is the data you should use to answer the question:
- Transactions Data (JSON): {{{transactions}}}
- Vehicles Data (JSON): {{{vehicles}}}

Owner's Question: "{{question}}"

Analyze the data to answer the question. If the question cannot be answered with the given data, say so politely.
Examples of insights you can provide:
- Peak hours for vehicle entries.
- Average parking duration.
- Total revenue for a period.
- Most common vehicle type.
`,
});

// Define the Genkit Flow
const parkingInsightsFlow = ai.defineFlow(
  {
    name: 'parkingInsightsFlow',
    inputSchema: ParkingInsightsInputSchema,
    outputSchema: ParkingInsightsOutputSchema,
  },
  async (input) => {
    // Generate the response using the prompt.
    const llmResponse = await parkingInsightsPrompt(input);
    return llmResponse.text;
  }
);
