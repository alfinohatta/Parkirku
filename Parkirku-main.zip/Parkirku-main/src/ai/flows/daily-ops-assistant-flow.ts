'use server';
/**
 * @fileOverview An AI flow for assisting with daily parking operations.
 *
 * - getDailyOpsInsight - A function that answers questions about daily operations.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';
import { DailyOpsInputSchema, type DailyOpsInput } from '@/ai/types';

const DailyOpsOutputSchema = z.string();
type DailyOpsOutput = z.infer<typeof DailyOpsOutputSchema>;

export async function getDailyOpsInsight(input: DailyOpsInput): Promise<string> {
  return dailyOpsFlow(input);
}

const dailyOpsPrompt = ai.definePrompt({
  name: 'dailyOpsPrompt',
  input: { schema: DailyOpsInputSchema },
  output: { format: 'text' },
  prompt: `You are a Daily Operations Assistant for a parking system.
You help Admins and Parking Attendants (Petugas) get quick information about the current state of operations.
The current user asking the question is: {{currentUser}}. Be friendly, concise, and helpful. Today's date is ${new Date().toLocaleDateString()}.

Use the following data to answer the questions:
- Today's Transactions (JSON): {{{todayTransactions}}}
- All Users (JSON): {{{users}}}
- Parking Areas (JSON): {{{parkingAreas}}}

User's Question: "{{question}}"

Analyze the data to answer the question. If the data is insufficient, say so politely.
Examples of how to answer:
- For "Jumlah kendaraan hari ini berapa?", count the number of unique vehicles from today's transactions that have entered today.
- For "Pendapatan parkir hari ini?", sum the 'biaya_total' from today's completed transactions.
- For "Shift petugas sekarang siapa?", identify attendants (users with role 'Petugas') who have checked in or checked out vehicles today based on 'id_petugas_masuk' and 'id_petugas_keluar' in the transactions. You can also mention the user asking the question if they are an attendant.
- If asked about available slots, use the 'kapasitas' and 'terisi' from the parking areas data to calculate and show availability per area.
`,
});

const dailyOpsFlow = ai.defineFlow(
  {
    name: 'dailyOpsFlow',
    inputSchema: DailyOpsInputSchema,
    outputSchema: DailyOpsOutputSchema,
  },
  async (input) => {
    const llmResponse = await dailyOpsPrompt(input);
    return llmResponse.text;
  }
);
