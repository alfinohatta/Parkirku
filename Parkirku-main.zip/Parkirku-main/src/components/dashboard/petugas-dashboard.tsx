'use client';

import { useState, useMemo, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useRealTime } from '@/hooks/use-real-time';
import { formatDistanceToNowStrict, parseISO, format, isToday } from 'date-fns';
import { LogIn, LogOut, Car as CarIcon, Bike, Building, Clock, ParkingSquare, Truck, ShieldAlert, Printer, Search, Bot, CreditCard, AlertCircle } from 'lucide-react';
import type { Transaction, Vehicle, ParkingArea, User, VehicleType, Tariff, ActivityLog } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { calculateFee } from '@/lib/utils';
import { Badge } from '../ui/badge';
import { mockTransactions, mockVehicles, mockParkingAreas, mockTariffs, mockSubscriptions, mockUsers, mockActivityLogs } from '@/lib/data';
import { Textarea } from '../ui/textarea';
import usePersistentState from '@/hooks/use-persistent-state';
import LogoutButton from '../layout/logout-button';
import { getDailyOpsInsight } from '@/ai/flows/daily-ops-assistant-flow';
import { DailyOpsInput } from '@/ai/types';
import { Skeleton } from '../ui/skeleton';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from '../ui/chart';
import { Bar, BarChart, CartesianGrid, Legend, Tooltip, XAxis, YAxis } from 'recharts';
import { Label } from '../ui/label';

// Stripe Imports
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { createPaymentIntent } from '@/app/actions/stripe';
import StripePaymentForm from './stripe-payment-form';

// Initialize Stripe outside of component to ensure it's only done once
// Hardcoded fallback for testing as requested by user
const stripePublicKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || 'pk_test_51TIt4APgZwkxwpTd2pszIq73P14BkmCkZPklaCFXGO10xk5BulqDmAqWtYx4DZN05U2YbNNxKWQNnvwDOkLPkLFY00mVUofCaX';
const stripePromise = loadStripe(stripePublicKey);

const VehicleIcon = ({ type }: { type: VehicleType }) => {
  switch (type) {
    case 'Motor':
      return <Bike className="h-5 w-5" />;
    case 'Mobil':
      return <CarIcon className="h-5 w-5" />;
    case 'Mobil Box':
      return <Truck className="h-5 w-5" />;
    case 'Valet':
      return <CarIcon className="h-5 w-5 text-accent-foreground" />;
    default:
      return <CarIcon className="h-5 w-5" />;
  }
};

const activityChartConfig = {
  CheckIns: {
    label: 'Check-Ins',
    color: 'hsl(var(--chart-1))',
  },
  CheckOuts: {
    label: 'Check-Outs',
    color: 'hsl(var(--chart-2))',
  },
} satisfies ChartConfig;

const checkInSchema = z.object({
    plate: z.string().min(3, { message: 'Plate number must be at least 3 characters.' }).max(15, { message: 'Plate number must be 15 characters or less.' }).transform(val => val.toUpperCase()),
    pemilik: z.string().min(3, { message: "Owner's name must be at least 3 characters." }).max(50, { message: "Owner's name cannot exceed 50 characters." }).optional().or(z.literal('')),
    warna: z.string().min(3, { message: "Color must be at least 3 characters." }).max(30, { message: "Color cannot exceed 30 characters." }).optional().or(z.literal('')),
    type: z.string({ required_error: "Vehicle type is required." }),
    area: z.string({ required_error: "Parking area is required." }),
});

export default function PetugasDashboard({ currentUser }: { currentUser: User }) {
  const [transactions, setTransactions] = usePersistentState('transactions', mockTransactions);
  const [vehicles, setVehicles] = usePersistentState('vehicles', mockVehicles);
  const [areas, setAreas] = usePersistentState('parkingAreas', mockParkingAreas);
  const [tariffs] = usePersistentState('tariffs', mockTariffs);
  const [subscriptions] = usePersistentState('subscriptions', mockSubscriptions);
  const [activityLogs, setActivityLogs] = usePersistentState('activityLogs', mockActivityLogs);
  const [users] = usePersistentState('users', mockUsers);

  const [searchQuery, setSearchQuery] = useState('');
  const [isCheckInOpen, setIsCheckInOpen] = useState(false);
  const [isCheckOutOpen, setIsCheckOutOpen] = useState(false);
  const [isForceCheckOutOpen, setIsForceCheckOutOpen] = useState(false);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [receiptData, setReceiptData] = useState<Transaction | null>(null);
  const [checkOutDetails, setCheckOutDetails] = useState({ fee: 0, duration: 0 });
  const [overrideReason, setOverrideReason] = useState('');

  // Stripe States
  const [stripeClientSecret, setStripeClientSecret] = useState<string | null>(null);
  const [isStripeLoading, setIsStripeLoading] = useState(false);

  const [aiQuestion, setAiQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const [parkedPlateFilter, setParkedPlateFilter] = useState('');
  const [parkedAreaFilter, setParkedAreaFilter] = useState('all');
  const [parkedTypeFilter, setParkedTypeFilter] = useState('all');

  const { toast } = useToast();
  const now = useRealTime();

  const checkInForm = useForm<z.infer<typeof checkInSchema>>({
    resolver: zodResolver(checkInSchema),
    defaultValues: {
      plate: '',
      pemilik: '',
      warna: '',
      type: undefined,
      area: undefined,
    },
  });

  useEffect(() => {
    if(!isCheckInOpen) {
      checkInForm.reset();
    }
  }, [isCheckInOpen, checkInForm]);
  

  const parkedVehicles = useMemo(() => {
    const activeTransactions = transactions.filter((t: Transaction) => t.status === 'di_dalam');
    
    return activeTransactions.filter(t => {
      const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === t.id_kendaraan);
      if (!vehicle) return false;

      const plateMatch = parkedPlateFilter ? vehicle.plat_nomor.includes(parkedPlateFilter.toUpperCase()) : true;
      const areaMatch = parkedAreaFilter === 'all' ? true : t.id_area.toString() === parkedAreaFilter;
      const typeMatch = parkedTypeFilter === 'all' ? true : vehicle.jenis_kendaraan === parkedTypeFilter;

      return plateMatch && areaMatch && typeMatch;
    });

  }, [transactions, vehicles, parkedPlateFilter, parkedAreaFilter, parkedTypeFilter]);


  const addLog = (activity: string) => {
    const newLog: ActivityLog = {
      id_log: Date.now(),
      id_user: currentUser.id_user,
      aktivitas: activity,
      waktu_aktivitas: new Date().toISOString(),
    };
    setActivityLogs((prevLogs) => [newLog, ...prevLogs]);
  };
  
  const handleAskAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestion.trim()) return;

    setIsAiLoading(true);
    setAiAnswer('');

    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const todayTransactions = transactions.filter((t: Transaction) => new Date(t.waktu_masuk) >= today);

        const input: DailyOpsInput = {
            question: aiQuestion,
            todayTransactions: JSON.stringify(todayTransactions),
            users: JSON.stringify(users),
            parkingAreas: JSON.stringify(areas),
            currentUser: JSON.stringify(currentUser),
        };

        const answer = await getDailyOpsInsight(input);
        setAiAnswer(answer);
    } catch (error) {
        console.error('Error getting AI insight:', error);
        setAiAnswer('Sorry, I encountered an error while processing your request. Please try again.');
    } finally {
        setIsAiLoading(false);
    }
  };

  const handleCheckIn = (values: z.infer<typeof checkInSchema>) => {
    const { plate, type, area, pemilik, warna } = values;
    const areaId = parseInt(area, 10);

    const existingVehicle = vehicles.find((v: Vehicle) => v.plat_nomor === plate);
    if (existingVehicle && transactions.some((t: Transaction) => t.id_kendaraan === existingVehicle.id_kendaraan && t.status === 'di_dalam')) {
      toast({ title: 'Error', description: 'This vehicle is already parked.', variant: 'destructive' });
      return;
    }

    const selectedArea = areas.find((a: ParkingArea) => a.id_area === areaId);
    if (selectedArea && selectedArea.terisi >= selectedArea.kapasitas) {
      toast({ title: 'Error', description: 'Selected parking area is full.', variant: 'destructive' });
      return;
    }

    let vehicle = vehicles.find((v: Vehicle) => v.plat_nomor === plate);
    if (!vehicle) {
      const newVehicleId = vehicles.length > 0 ? Math.max(...vehicles.map((v: Vehicle) => v.id_kendaraan)) + 1 : 1;
      const newVehicle: Vehicle = {
        id_kendaraan: newVehicleId,
        plat_nomor: plate,
        jenis_kendaraan: type,
        pemilik: pemilik || 'N/A',
        warna: warna || 'N/A',
      };
      setVehicles((prev) => [...prev, newVehicle]);
      vehicle = newVehicle;
    } else {
      setVehicles((prev) =>
        prev.map((v: Vehicle) =>
          v.id_kendaraan === vehicle!.id_kendaraan ? { ...v, pemilik: pemilik || v.pemilik, warna: warna || v.warna } : v
        )
      );
    }
    
    const tariff = tariffs.find((t: Tariff) => t.jenis_kendaraan === type);

    if (!vehicle || !tariff) {
      toast({ title: 'Error', description: 'Could not find a valid vehicle or tariff.', variant: 'destructive' });
      return;
    }

    const newTransaction: Transaction = {
      id_parkir: transactions.length > 0 ? Math.max(...transactions.map((t: Transaction) => t.id_parkir)) + 1 : 1,
      id_kendaraan: vehicle.id_kendaraan,
      waktu_masuk: new Date().toISOString(),
      waktu_keluar: null,
      id_tarif: tariff.id_tarif,
      id_area: areaId,
      status: 'di_dalam',
      id_petugas_masuk: currentUser.id_user,
      id_petugas_keluar: null,
      durasi_jam: null,
      biaya_total: null,
      metode_pembayaran: null,
    };

    setTransactions((prev) => [...prev, newTransaction]);
    setAreas((prev) => prev.map((a: ParkingArea) => (a.id_area === areaId ? { ...a, terisi: a.terisi + 1 } : a)));

    addLog(`Checked in vehicle ${plate}.`);
    toast({ title: 'Success', description: `Vehicle ${plate} checked in.` });
    setIsCheckInOpen(false);
  };

  const openCheckOutDialog = (transaction: Transaction) => {
    const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === transaction.id_kendaraan);
    const isMember = subscriptions.some((s: any) => s.plat_nomor === vehicle?.plat_nomor && s.aktif);
    const tempTransaction = { ...transaction, waktu_keluar: new Date().toISOString() };
    const { totalFee, durationHours } = calculateFee(tempTransaction, tariffs, isMember);

    setSelectedTransaction(tempTransaction);
    setCheckOutDetails({ fee: totalFee, duration: durationHours });
    setStripeClientSecret(null); // Reset Stripe state
    setIsCheckOutOpen(true);
  };

  const initiateStripePayment = async () => {
    if (!stripePromise) {
      toast({
        variant: 'destructive',
        title: 'Configuration Error',
        description: 'Stripe failed to initialize. Please check API keys.',
      });
      return;
    }

    if (checkOutDetails.fee < 10000) {
      toast({
        variant: 'destructive',
        title: 'Minimum Payment Not Met',
        description: 'Online payment is only available for transactions above Rp 10.000.',
      });
      return;
    }

    setIsStripeLoading(true);
    try {
      const { clientSecret } = await createPaymentIntent(checkOutDetails.fee);
      setStripeClientSecret(clientSecret || null);
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Payment Error',
        description: error.message || 'Failed to initialize payment.',
      });
    } finally {
      setIsStripeLoading(false);
    }
  };

  const processCheckout = (finalTransaction: Transaction) => {
    setTransactions((prev) => prev.map((t: Transaction) => (t.id_parkir === finalTransaction.id_parkir ? finalTransaction : t)));
    setAreas((prev) =>
      prev.map((a: ParkingArea) =>
        a.id_area === finalTransaction.id_area ? { ...a, terisi: Math.max(0, a.terisi - 1) } : a
      )
    );
    
    const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === finalTransaction.id_kendaraan);
    addLog(`Checked out vehicle ${vehicle?.plat_nomor}. Fee: Rp ${finalTransaction.biaya_total?.toLocaleString()}. Payment: ${finalTransaction.metode_pembayaran}.`);
    toast({ title: 'Success', description: `Vehicle checked out. Fee: Rp ${finalTransaction.biaya_total?.toLocaleString()}` });

    setIsCheckOutOpen(false);
    setReceiptData(finalTransaction);
    setIsReceiptOpen(true);
  };

  const handleCheckOut = (paymentMethod: 'tunai' | 'qris' | 'debit' | 'member' | 'stripe') => {
    if (!selectedTransaction) return;

    const finalTransaction = {
      ...selectedTransaction,
      status: 'selesai' as const,
      id_petugas_keluar: currentUser.id_user,
      durasi_jam: checkOutDetails.duration,
      biaya_total: checkOutDetails.fee,
      metode_pembayaran: paymentMethod,
    };
    processCheckout(finalTransaction);
  };

  const handleForceCheckout = () => {
    if (!selectedTransaction || !overrideReason) {
      toast({ title: 'Error', description: 'Override reason is required.', variant: 'destructive' });
      return;
    }
    const finalTransaction: Transaction = {
      ...selectedTransaction,
      status: 'selesai',
      id_petugas_keluar: currentUser.id_user,
      durasi_jam: checkOutDetails.duration,
      biaya_total: 0,
      metode_pembayaran: 'override',
      alasan_override: overrideReason,
    };
    
    const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === finalTransaction.id_kendaraan);
    addLog(`Force checked out vehicle ${vehicle?.plat_nomor}. Reason: ${overrideReason}.`);
    processCheckout(finalTransaction);
    setIsForceCheckOutOpen(false);
    setOverrideReason('');
  };
  
  const handleSearchTransaction = (event: React.FormEvent) => {
    event.preventDefault();
    if (!searchQuery) {
        toast({ title: 'Input Required', description: 'Please enter a plate number or transaction ID.', variant: 'destructive' });
        return;
    }

    const upperCaseQuery = searchQuery.toUpperCase();

    const foundTransaction = transactions.find(
      (t: Transaction) =>
        t.status === 'di_dalam' &&
        (t.id_parkir.toString() === searchQuery ||
          vehicles.find((v: Vehicle) => v.id_kendaraan === t.id_kendaraan)?.plat_nomor === upperCaseQuery)
    );

    if (foundTransaction) {
      openCheckOutDialog(foundTransaction);
    } else {
      toast({
        title: 'Transaction Not Found',
        description: `No active transaction found for '${searchQuery}'.`,
        variant: 'destructive',
      });
    }
    setSearchQuery(''); // Clear input after search
  };

  const myActivityData = useMemo(() => {
    const myCheckIns = transactions.filter(t => isToday(new Date(t.waktu_masuk)) && t.id_petugas_masuk === currentUser.id_user).length;
    const myCheckOuts = transactions.filter(t => t.waktu_keluar && isToday(new Date(t.waktu_keluar)) && t.id_petugas_keluar === currentUser.id_user).length;
    return [{ name: 'Today', CheckIns: myCheckIns, CheckOuts: myCheckOuts }];
  }, [transactions, currentUser]);


  const vehicleDetails = selectedTransaction ? vehicles.find((v: Vehicle) => v.id_kendaraan === selectedTransaction.id_kendaraan) : null;
  const receiptPetugasMasuk = receiptData ? users.find((u) => u.id_user === receiptData.id_petugas_masuk) : null;
  const receiptPetugasKeluar = receiptData ? users.find((u) => u.id_user === receiptData.id_petugas_keluar) : null;
  const receiptVehicle = receiptData ? vehicles.find((v: Vehicle) => v.id_kendaraan === receiptData.id_kendaraan) : null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
            <h1 className="text-3xl font-bold tracking-tight">Petugas Dashboard</h1>
            <p className="text-muted-foreground">Welcome, {currentUser.nama_lengkap}. You are now ready to manage parking.</p>
        </div>
        <LogoutButton currentUser={currentUser} />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {areas.map((area: ParkingArea) => (
          <Card key={area.id_area}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{area.nama_area}</CardTitle>
              <ParkingSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {area.terisi} / {area.kapasitas}
              </div>
              <p className="text-xs text-muted-foreground">{area.kapasitas - area.terisi} spots available</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
            <CardHeader>
                <CardTitle>Check-In Vehicle</CardTitle>
                <CardDescription>Start a new parking session.</CardDescription>
            </CardHeader>
            <CardContent>
                <Dialog open={isCheckInOpen} onOpenChange={setIsCheckInOpen}>
                    <DialogTrigger asChild>
                        <Button className="w-full">
                            <LogIn className="mr-2 h-4 w-4" /> New Check-In
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>New Vehicle Check-In</DialogTitle>
                            <DialogDescription>Enter vehicle details to start a new parking session.</DialogDescription>
                        </DialogHeader>
                        <Form {...checkInForm}>
                          <form onSubmit={checkInForm.handleSubmit(handleCheckIn)} className="space-y-4">
                              <FormField control={checkInForm.control} name="plate" render={({ field }) => (
                                  <FormItem>
                                      <FormLabel>Plate Number</FormLabel>
                                      <FormControl>
                                          <Input placeholder="B 1234 ABC" {...field} className="font-code" maxLength={15} />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )} />
                              <FormField control={checkInForm.control} name="pemilik" render={({ field }) => (
                                  <FormItem>
                                      <FormLabel>Owner Name (Optional)</FormLabel>
                                      <FormControl>
                                          <Input placeholder="e.g. John Doe" {...field} maxLength={50} />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )} />
                              <FormField control={checkInForm.control} name="warna" render={({ field }) => (
                                  <FormItem>
                                      <FormLabel>Color (Optional)</FormLabel>
                                      <FormControl>
                                          <Input placeholder="e.g. Hitam" {...field} maxLength={30} />
                                      </FormControl>
                                      <FormMessage />
                                  </FormItem>
                              )} />
                              <FormField control={checkInForm.control} name="type" render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Vehicle Type</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      {tariffs.map((t) => (
                                          <SelectItem key={t.id_tarif} value={t.jenis_kendaraan}>{t.jenis_kendaraan}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )} />
                               <FormField control={checkInForm.control} name="area" render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Parking Area</FormLabel>
                                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl>
                                      <SelectTrigger><SelectValue placeholder="Select area" /></SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      {areas.map((area: ParkingArea) => (
                                        <SelectItem key={area.id_area} value={area.id_area.toString()} disabled={area.terisi >= area.kapasitas}>
                                            {area.nama_area} ({area.terisi}/{area.kapasitas})
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )} />
                            <DialogFooter>
                              <Button type="submit">Confirm Check-In</Button>
                            </DialogFooter>
                          </form>
                        </Form>
                    </DialogContent>
                </Dialog>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle>Check-Out Vehicle</CardTitle>
                <CardDescription>Find a transaction to check-out.</CardDescription>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSearchTransaction}>
                    <div className="flex gap-2">
                        <Input 
                            placeholder="Plate Number or Transaction ID..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            maxLength={20}
                        />
                        <Button type="submit">
                            <Search className="mr-2 h-4 w-4" /> Find
                        </Button>
                    </div>
                </form>
            </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle>My Daily Activity</CardTitle>
                <CardDescription>Your check-in and check-out count for today.</CardDescription>
            </CardHeader>
            <CardContent>
                 <ChartContainer config={activityChartConfig} className="h-24 w-full">
                    <BarChart data={myActivityData} layout="vertical" margin={{ left: 10 }}>
                        <XAxis type="number" hide />
                        <YAxis type="category" dataKey="name" hide />
                        <Tooltip content={<ChartTooltipContent />} cursor={false} />
                        <Legend />
                        <Bar dataKey="CheckIns" fill="var(--color-CheckIns)" radius={4} stackId="a" />
                        <Bar dataKey="CheckOuts" fill="var(--color-CheckOuts)" radius={4} stackId="a" />
                    </BarChart>
                 </ChartContainer>
            </CardContent>
        </Card>
        <Card className="md:col-span-3">
            <CardHeader>
                <div className="flex items-center gap-2">
                    <Bot className="h-6 w-6" />
                    <CardTitle>Daily Operations Assistant</CardTitle>
                </div>
                <CardDescription>Ask questions for quick operational updates.</CardDescription>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleAskAi} className="space-y-4">
                    <Textarea
                        placeholder="e.g., Pendapatan hari ini berapa?"
                        value={aiQuestion}
                        onChange={(e) => setAiQuestion(e.target.value)}
                        disabled={isAiLoading}
                        maxLength={200}
                    />
                    <Button type="submit" disabled={isAiLoading}>
                        {isAiLoading ? 'Thinking...' : 'Ask AI'}
                    </Button>
                </form>
            </CardContent>
            {(isAiLoading || aiAnswer) && (
                <CardFooter>
                    <div className="w-full space-y-2 rounded-md border border-muted bg-muted/50 p-4 text-sm">
                        <p className="font-medium">AI Assistant:</p>
                        {isAiLoading ? (
                        <div className="space-y-2">
                            <Skeleton className="h-4 w-5/6" />
                            <Skeleton className="h-4 w-full" />
                            <Skeleton className="h-4 w-4/6" />
                        </div>
                        ) : (
                            <p className="whitespace-pre-wrap">{aiAnswer}</p>
                        )}
                    </div>
                </CardFooter>
            )}
        </Card>
      </div>

      <Card>
        <CardHeader>
            <CardTitle className="font-headline">Currently Parked Vehicles</CardTitle>
            <CardDescription>{parkedVehicles.length} vehicles currently in parking areas.</CardDescription>
            <div className="flex flex-wrap gap-4 pt-4">
                <div className="grid gap-2">
                    <Label>Filter by Plate</Label>
                    <Input 
                        placeholder="Search plate..."
                        value={parkedPlateFilter}
                        onChange={(e) => setParkedPlateFilter(e.target.value)}
                        className="w-[180px]"
                        maxLength={15}
                    />
                </div>
                <div className="grid gap-2">
                    <Label>Filter by Area</Label>
                    <Select value={parkedAreaFilter} onValueChange={setParkedAreaFilter}>
                        <SelectTrigger className="w-[180px]">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Areas</SelectItem>
                            {areas.map((area) => (
                                <SelectItem key={area.id_area} value={area.id_area.toString()}>
                                    {area.nama_area}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="grid gap-2">
                    <Label>Filter by Type</Label>
                    <Select value={parkedTypeFilter} onValueChange={setParkedTypeFilter}>
                        <SelectTrigger className="w-[180px]">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Types</SelectItem>
                             {tariffs.map((tariff) => (
                                <SelectItem key={tariff.id_tarif} value={tariff.jenis_kendaraan}>
                                    {tariff.jenis_kendaraan}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Plate Number</TableHead>
                  <TableHead>Vehicle Type</TableHead>
                  <TableHead>Parking Area</TableHead>
                  <TableHead>Entry Time</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {parkedVehicles.length > 0 ? (
                  parkedVehicles.map((t: Transaction) => {
                    const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === t.id_kendaraan);
                    const area = areas.find((a: ParkingArea) => a.id_area === t.id_area);
                    const isMember = subscriptions.some((s: any) => s.plat_nomor === vehicle?.plat_nomor && s.aktif);
                    return (
                      <TableRow key={t.id_parkir}>
                        <TableCell className="font-code font-semibold">
                          <div className="flex items-center gap-2">
                            {vehicle?.plat_nomor} {isMember && <Badge variant="secondary">Member</Badge>}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <VehicleIcon type={vehicle?.jenis_kendaraan || 'Mobil'} />
                            <span>{vehicle?.jenis_kendaraan}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Building className="h-4 w-4 text-muted-foreground" />
                            <span>{area?.nama_area}</span>
                          </div>
                        </TableCell>
                        <TableCell>{now && t.waktu_masuk ? format(parseISO(t.waktu_masuk), 'Pp') : '...'}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{now && t.waktu_masuk ? formatDistanceToNowStrict(parseISO(t.waktu_masuk)) : '...'}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button size="sm" onClick={() => openCheckOutDialog(t)}>
                            <LogOut className="mr-2 h-4 w-4" /> Check Out
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      No vehicles found matching filters.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      {selectedTransaction && (
        <Dialog open={isCheckOutOpen} onOpenChange={setIsCheckOutOpen}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Confirm Check-Out</DialogTitle>
              <DialogDescription>
                Vehicle: <span className="font-code font-bold text-primary">{vehicleDetails?.plat_nomor}</span>
                <br />
                <span className="text-sm text-muted-foreground">
                  Owner: {vehicleDetails?.pemilik || 'N/A'} - Color: {vehicleDetails?.warna || 'N/A'}
                </span>
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <span className="text-muted-foreground">Entry Time:</span> 
                <span className="text-right font-medium">{now && selectedTransaction.waktu_masuk ? format(parseISO(selectedTransaction.waktu_masuk), 'Pp') : '...'}</span>
                
                <span className="text-muted-foreground">Exit Time:</span> 
                <span className="text-right font-medium">{now && selectedTransaction.waktu_keluar ? format(parseISO(selectedTransaction.waktu_keluar), 'Pp') : '...'}</span>
                
                <span className="text-muted-foreground">Duration:</span> 
                <span className="text-right font-medium">{checkOutDetails.duration} hour(s)</span>
              </div>
              
              <div className="text-2xl font-bold flex justify-between items-center border-t border-dashed pt-4 mt-4">
                <span>Total Fee:</span> 
                <span className="text-primary">Rp {checkOutDetails.fee.toLocaleString()}</span>
              </div>

              {/* Stripe Payment Integration Section */}
              {stripeClientSecret ? (
                <div className="mt-4 pt-4 border-t">
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <CreditCard className="h-4 w-4" /> Secure Online Payment (Stripe)
                  </h4>
                  <Elements stripe={stripePromise} options={{ clientSecret: stripeClientSecret }}>
                    <StripePaymentForm 
                      clientSecret={stripeClientSecret} 
                      amount={checkOutDetails.fee}
                      onSuccess={() => handleCheckOut('stripe')}
                      onCancel={() => setStripeClientSecret(null)}
                    />
                  </Elements>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" className="gap-2" onClick={() => handleCheckOut('tunai')}>
                      Pay Cash
                    </Button>
                    <Button variant="outline" className="gap-2" onClick={() => handleCheckOut('qris')}>
                      Pay QRIS
                    </Button>
                    <Button variant="outline" className="gap-2" onClick={() => handleCheckOut('debit')}>
                      Pay Debit
                    </Button>
                    <div className="flex flex-col gap-1">
                      <Button 
                        variant="default" 
                        className="gap-2 bg-indigo-600 hover:bg-indigo-700 text-white w-full" 
                        onClick={initiateStripePayment}
                        disabled={isStripeLoading || checkOutDetails.fee < 10000}
                      >
                        {isStripeLoading ? 'Starting...' : 'Pay with Stripe'}
                      </Button>
                      {(checkOutDetails.fee > 0 && checkOutDetails.fee < 10000) && (
                        <p className="text-[10px] text-destructive flex items-center gap-1 font-medium">
                          <AlertCircle className="h-3 w-3" /> Minimum payment for Stripe is Rp 10.000
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {!stripeClientSecret && (
              <DialogFooter className="flex flex-col sm:flex-row gap-2 pt-4 border-t">
                <Button variant="destructive" className="sm:mr-auto" onClick={() => setIsForceCheckOutOpen(true)}>
                  <ShieldAlert className="mr-2 h-4 w-4" /> Force Checkout
                </Button>
                <Button variant="ghost" onClick={() => setIsCheckOutOpen(false)}>
                  Close
                </Button>
              </DialogFooter>
            )}
          </DialogContent>
        </Dialog>
      )}

      <Dialog open={isForceCheckOutOpen} onOpenChange={setIsForceCheckOutOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Force Checkout Confirmation</DialogTitle>
            <DialogDescription>
              You are about to force a checkout for vehicle <span className="font-code font-bold">{vehicleDetails?.plat_nomor}</span>. The fee will be Rp 0. Please provide a mandatory reason below.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="override-reason">Reason</Label>
            <Textarea id="override-reason" placeholder="e.g., Vehicle broke down, Ambulance, Management decision, etc." value={overrideReason} onChange={(e) => setOverrideReason(e.target.value)} maxLength={150} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsForceCheckOutOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleForceCheckout} disabled={!overrideReason}>
              Confirm Force Checkout
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {receiptData && (
        <Dialog open={isReceiptOpen} onOpenChange={setIsReceiptOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader className="print:hidden">
              <DialogTitle>Parking Receipt</DialogTitle>
              <DialogDescription>Transaction receipt for vehicle {receiptVehicle?.plat_nomor}. Ready to print.</DialogDescription>
            </DialogHeader>
            <div id="receipt-content" className="text-black bg-white p-6">
                <div className="text-center space-y-1">
                    <div className="flex items-center justify-center gap-2">
                        <CarIcon className="h-8 w-8 text-black" />
                        <h2 className="text-2xl font-bold font-headline">ParkRight</h2>
                    </div>
                    <p className="text-sm">Struk Parkir</p>
                    <p className="text-xs">Jl. Parkir Aman No. 1, Jakarta</p>
                </div>

                <div className="border-t border-dashed border-black my-4"></div>

                <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="font-medium">ID Transaksi:</span>
                        <span className="font-mono">{receiptData.id_parkir}</span>
                    </div>
                     <div className="flex justify-between">
                        <span className="font-medium">Plat Nomor:</span>
                        <span className="font-mono font-bold">{receiptVehicle?.plat_nomor}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="font-medium">Jenis Kendaraan:</span>
                        <span>{receiptVehicle?.jenis_kendaraan}</span>
                    </div>
                </div>

                <div className="border-t border-dashed border-black my-4"></div>
                
                <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span>Masuk:</span>
                        <span className="font-mono">{format(parseISO(receiptData.waktu_masuk), 'dd/MM/yy HH:mm')}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Keluar:</span>
                        <span className="font-mono">{receiptData.waktu_keluar ? format(parseISO(receiptData.waktu_keluar), 'dd/MM/yy HH:mm') : '-'}</span>
                    </div>
                     <div className="flex justify-between">
                        <span>Durasi:</span>
                        <span>{receiptData.durasi_jam} jam</span>
                    </div>
                </div>

                <div className="border-t border-dashed border-black my-4"></div>

                <div className="space-y-2">
                    <div className="flex justify-between font-bold text-lg">
                        <span>TOTAL BAYAR:</span>
                        <span className="font-mono">Rp {receiptData.biaya_total?.toLocaleString() || '0'}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                        <span>Metode Bayar:</span>
                        <span className="font-medium capitalize">{receiptData.metode_pembayaran}</span>
                    </div>
                </div>

                 {receiptData.alasan_override && (
                    <>
                        <div className="border-t border-dashed border-black my-4"></div>
                        <div className="text-center text-sm bg-yellow-100 p-2 rounded-md">
                           <p className="font-bold">TRANSAKSI OVERRIDE</p>
                           <p>Alasan: {receiptData.alasan_override}</p>
                        </div>
                    </>
                )}
                
                <div className="border-t border-dashed border-black my-4"></div>
                
                <div className="text-center text-xs space-y-1">
                    <p>Petugas Masuk: {receiptPetugasMasuk?.nama_lengkap || '-'}</p>
                    <p>Petugas Keluar: {receiptPetugasKeluar?.nama_lengkap || '-'}</p>
                    <p className="font-bold pt-2">Terima kasih atas kunjungan Anda!</p>
                </div>
            </div>
            <DialogFooter className="print:hidden">
              <Button variant="outline" onClick={() => setIsReceiptOpen(false)}>
                Close
              </Button>
              <Button onClick={() => window.print()}>
                <Printer className="mr-2 h-4 w-4" /> Cetak / Simpan PDF
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
