'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { DollarSign, Car, Clock, Calendar as CalendarIcon, Bot, History, Filter, X, LayoutDashboard, ListChecks } from 'lucide-react';
import type { Transaction, Vehicle, User, ParkingArea, ActivityLog, VehicleType } from '@/lib/types';
import { mockTransactions, mockVehicles, mockUsers, mockParkingAreas, mockActivityLogs, mockTariffs } from '@/lib/data';
import { useState, useMemo } from 'react';
import { Bar, BarChart, CartesianGrid, Tooltip, XAxis, YAxis, PieChart, Pie, Cell, Legend, LineChart, Line } from 'recharts';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';
import { DateRange } from 'react-day-picker';
import { format, subDays, formatDistanceToNow, isWithinInterval, startOfDay, endOfDay } from 'date-fns';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Calendar } from '../ui/calendar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import usePersistentState from '@/hooks/use-persistent-state';
import LogoutButton from '../layout/logout-button';
import { getParkingInsights } from '@/ai/flows/parking-insights-flow';
import type { ParkingInsightsInput } from '@/ai/types';
import { Textarea } from '../ui/textarea';
import { Skeleton } from '../ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

const revenueChartConfig = {
  revenue: {
    label: 'Revenue',
    color: 'hsl(var(--chart-1))',
  },
} satisfies ChartConfig;

const peakHoursChartConfig = {
  vehicles: {
    label: 'Vehicles',
    color: 'hsl(var(--chart-1))',
  },
} satisfies ChartConfig;

const PIE_CHART_COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))'
];

export default function OwnerDashboard({ currentUser }: { currentUser: User }) {
  const [date, setDate] = useState<DateRange | undefined>({
    from: subDays(new Date(), 29),
    to: new Date(),
  });

  const [transactions] = usePersistentState('transactions', mockTransactions);
  const [vehicles] = usePersistentState('vehicles', mockVehicles);
  const [users] = usePersistentState('users', mockUsers);
  const [areas] = usePersistentState('parkingAreas', mockParkingAreas);
  const [activityLogs] = usePersistentState('activityLogs', mockActivityLogs);
  const [tariffs] = usePersistentState('tariffs', mockTariffs);

  const [aiQuestion, setAiQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const [logUserFilter, setLogUserFilter] = useState('all');
  const [paymentMethodFilter, setPaymentMethodFilter] = useState('all');
  const [areaFilter, setAreaFilter] = useState('all');
  const [vehicleTypeFilter, setVehicleTypeFilter] = useState('all');
  const [transactionStatusFilter, setTransactionStatusFilter] = useState('all');

  // Filter Transactions Logic (Includes completed and active if needed)
  const filteredTransactions = useMemo(() => {
    return transactions.filter((t: Transaction) => {
      // 1. Status Filter
      if (transactionStatusFilter !== 'all' && t.status !== transactionStatusFilter) return false;

      // 2. Date Filter (Always based on waktu_masuk or waktu_keluar depending on context)
      // For Owner report, we usually care about time when money was received (waktu_keluar) 
      // OR active presence (waktu_masuk). We use waktu_masuk as a fallback for date filtering.
      const targetDate = t.waktu_keluar ? new Date(t.waktu_keluar) : new Date(t.waktu_masuk);
      
      if (date?.from) {
        const start = startOfDay(date.from);
        const end = date.to ? endOfDay(date.to) : endOfDay(date.from);
        if (!isWithinInterval(targetDate, { start, end })) return false;
      }

      // 3. Payment Method Filter
      if (paymentMethodFilter !== 'all' && t.metode_pembayaran !== paymentMethodFilter) return false;

      // 4. Area Filter
      if (areaFilter !== 'all' && t.id_area.toString() !== areaFilter) return false;
      
      // 5. Vehicle Type Filter
      const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === t.id_kendaraan);
      if (vehicleTypeFilter !== 'all' && vehicle?.jenis_kendaraan !== vehicleTypeFilter) return false;

      return true;
    });
  }, [date, transactions, paymentMethodFilter, areaFilter, vehicleTypeFilter, transactionStatusFilter, vehicles]);
  
  // Stats calculation
  const completedTransactions = filteredTransactions.filter(t => t.status === 'selesai');
  const activeTransactions = transactions.filter(t => t.status === 'di_dalam');
  
  const totalRevenue = completedTransactions.reduce((sum, t) => sum + (t.biaya_total || 0), 0);
  const vehiclesProcessedCount = completedTransactions.length;
  const currentParkedCount = activeTransactions.length;
  const avgDuration = vehiclesProcessedCount > 0 
    ? completedTransactions.reduce((sum, t) => sum + (t.durasi_jam || 0), 0) / vehiclesProcessedCount 
    : 0;

  // Revenue Chart Data (Only completed ones)
  const revenueBarData = useMemo(() => {
    const revenueByDay = completedTransactions.reduce((acc, t) => {
      if (t.waktu_keluar) {
        const day = format(new Date(t.waktu_keluar), 'yyyy-MM-dd');
        acc[day] = (acc[day] || 0) + (t.biaya_total || 0);
      }
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(revenueByDay)
      .map(([date, revenue]) => ({ date, revenue }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [completedTransactions]);

  const vehicleMixData = useMemo(() => {
    const mix = filteredTransactions.reduce((acc, t) => {
      const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === t.id_kendaraan);
      if (vehicle) {
        const key = vehicle.jenis_kendaraan;
        acc[key] = (acc[key] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(mix).map(([name, value]) => ({ name, value }));
  }, [filteredTransactions, vehicles]);

  const peakHoursData = useMemo(() => {
    const hours = Array.from({ length: 24 }, (_, i) => ({ hour: i, vehicles: 0 }));
    filteredTransactions.forEach(t => {
      const entryHour = new Date(t.waktu_masuk).getHours();
      hours[entryHour].vehicles += 1;
    });
    return hours.map(h => ({ ...h, hour_label: `${String(h.hour).padStart(2, '0')}:00` }));
  }, [filteredTransactions]);

  const activeFiltersCount = [
    paymentMethodFilter !== 'all',
    areaFilter !== 'all',
    vehicleTypeFilter !== 'all',
    transactionStatusFilter !== 'all'
  ].filter(Boolean).length;

  const handleAskAi = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestion.trim()) return;

    setIsAiLoading(true);
    setAiAnswer('');

    try {
        const transactionContext = filteredTransactions.map(t => ({
            status: t.status,
            waktu_masuk: t.waktu_masuk,
            waktu_keluar: t.waktu_keluar,
            durasi_jam: t.durasi_jam,
            biaya_total: t.biaya_total,
            metode_pembayaran: t.metode_pembayaran,
        }));

        const input: ParkingInsightsInput = {
            question: aiQuestion,
            transactions: JSON.stringify(transactionContext),
            vehicles: JSON.stringify(vehicles.map(v => ({ plat: v.plat_nomor, tipe: v.jenis_kendaraan }))),
            dateRange: {
                from: date?.from ? format(date.from, 'PPP') : 'N/A',
                to: date?.to ? format(date.to, 'PPP') : 'N/A',
            }
        };

        const answer = await getParkingInsights(input);
        setAiAnswer(answer);
    } catch (error) {
        setAiAnswer('Error processing AI request.');
    } finally {
        setIsAiLoading(false);
    }
  };

  const clearFilters = () => {
    setPaymentMethodFilter('all');
    setAreaFilter('all');
    setVehicleTypeFilter('all');
    setTransactionStatusFilter('all');
  };

  const filteredLogs = useMemo(() => {
    return activityLogs.filter((log: ActivityLog) => {
        const logDate = new Date(log.waktu_aktivitas);
        if (date?.from) {
            const start = startOfDay(date.from);
            const end = date.to ? endOfDay(date.to) : endOfDay(date.from);
            if (!isWithinInterval(logDate, { start, end })) return false;
        }
        if (logUserFilter !== 'all' && log.id_user.toString() !== logUserFilter) return false;
        return true;
    });
  }, [activityLogs, date, logUserFilter]);

  return (
    <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
                <h1 className="text-3xl font-bold tracking-tight">Owner's Dashboard</h1>
                <p className="text-muted-foreground">Monitor real-time performance and financial health.</p>
            </div>
            <LogoutButton currentUser={currentUser} />
        </div>

        <Card className="border-primary/20 shadow-sm">
            <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                        <Filter className="h-5 w-5 text-primary" /> Analysis Filters
                    </CardTitle>
                    {activeFiltersCount > 0 && (
                        <Button variant="ghost" size="sm" onClick={clearFilters} className="text-destructive hover:text-destructive">
                            <X className="mr-2 h-4 w-4" /> Clear All
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="space-y-2">
                        <Label>Reporting Period</Label>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}>
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {date?.from ? (date.to ? `${format(date.from, "LLL dd")} - ${format(date.to, "LLL dd, y")}` : format(date.from, "LLL dd, y")) : "Select Range"}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                                <Calendar initialFocus mode="range" selected={date} onSelect={setDate} numberOfMonths={2} />
                            </PopoverContent>
                        </Popover>
                    </div>
                    <div className="space-y-2">
                        <Label>Transaction Status</Label>
                        <Select value={transactionStatusFilter} onValueChange={setTransactionStatusFilter}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Statuses</SelectItem>
                                <SelectItem value="selesai">Completed (Paid)</SelectItem>
                                <SelectItem value="di_dalam">Active (Parked)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Parking Area</Label>
                        <Select value={areaFilter} onValueChange={setAreaFilter}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Areas</SelectItem>
                                {areas.map(area => <SelectItem key={area.id_area} value={area.id_area.toString()}>{area.nama_area}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Vehicle Type</Label>
                        <Select value={vehicleTypeFilter} onValueChange={setVehicleTypeFilter}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Vehicle Types</SelectItem>
                                {tariffs.map(t => <SelectItem key={t.id_tarif} value={t.jenis_kendaraan}>{t.jenis_kendaraan}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </CardContent>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-primary/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    <DollarSign className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">Rp {totalRevenue.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">from {vehiclesProcessedCount} checkout(s)</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Currently Parked</CardTitle>
                    <Car className="h-4 w-4 text-accent-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{currentParkedCount}</div>
                    <p className="text-xs text-muted-foreground">vehicles in all areas</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Vehicles Processed</CardTitle>
                    <ListChecks className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{vehiclesProcessedCount}</div>
                    <p className="text-xs text-muted-foreground">in selected period</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                    <CardTitle className="text-sm font-medium">Avg. Park Time</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{avgDuration.toFixed(1)} h</div>
                    <p className="text-xs text-muted-foreground">average per checkout</p>
                </CardContent>
            </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
            <TabsList>
                <TabsTrigger value="overview" className="gap-2"><LayoutDashboard className="h-4 w-4" /> Analytics Overview</TabsTrigger>
                <TabsTrigger value="transactions" className="gap-2"><Car className="h-4 w-4" /> Transactions Detail</TabsTrigger>
                <TabsTrigger value="logs" className="gap-2"><History className="h-4 w-4" /> System Audit Logs</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="lg:col-span-2">
                        <CardHeader>
                            <CardTitle>Revenue Trend</CardTitle>
                            <CardDescription>Income generated daily from check-outs.</CardDescription>
                        </CardHeader>
                        <CardContent className="h-[300px]">
                            <ChartContainer config={revenueChartConfig} className="w-full h-full">
                                <BarChart data={revenueBarData}>
                                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                                    <XAxis dataKey="date" tickFormatter={(v) => format(new Date(v), 'MMM dd')} />
                                    <YAxis tickFormatter={(v) => `Rp${v/1000}k`} />
                                    <Tooltip content={<ChartTooltipContent />} />
                                    <Bar dataKey="revenue" fill="var(--color-revenue)" radius={[4, 4, 0, 0]} />
                                </BarChart>
                            </ChartContainer>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Vehicle Mix</CardTitle>
                            <CardDescription>Composition of vehicle types seen.</CardDescription>
                        </CardHeader>
                        <CardContent className="h-[300px]">
                            <ChartContainer config={{}} className="w-full h-full">
                                <PieChart>
                                    <Pie data={vehicleMixData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                                        {vehicleMixData.map((_, i) => <Cell key={i} fill={PIE_CHART_COLORS[i % PIE_CHART_COLORS.length]} />)}
                                    </Pie>
                                    <Tooltip />
                                    <Legend />
                                </PieChart>
                            </ChartContainer>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>Entry Peak Hours</CardTitle>
                            <CardDescription>When do vehicles usually arrive?</CardDescription>
                        </CardHeader>
                        <CardContent className="h-[300px]">
                            <ChartContainer config={peakHoursChartConfig} className="w-full h-full">
                                <LineChart data={peakHoursData}>
                                    <CartesianGrid vertical={false} />
                                    <XAxis dataKey="hour_label" interval={3} />
                                    <YAxis />
                                    <Tooltip content={<ChartTooltipContent />} />
                                    <Line type="monotone" dataKey="vehicles" stroke="var(--color-vehicles)" strokeWidth={2} dot={false} />
                                </LineChart>
                            </ChartContainer>
                        </CardContent>
                    </Card>
                </div>

                <Card className="bg-primary/5 border-primary/20">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5" /> Decision Support AI</CardTitle>
                        <CardDescription>Query your data using natural language.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Textarea 
                            placeholder="e.g., Kapan jam tersibuk dalam 1 minggu terakhir?" 
                            value={aiQuestion} 
                            onChange={(e) => setAiQuestion(e.target.value)} 
                            disabled={isAiLoading}
                            maxLength={200}
                        />
                        <Button onClick={handleAskAi} disabled={isAiLoading || !aiQuestion.trim()}>
                            {isAiLoading ? 'Analyzing...' : 'Generate Insight'}
                        </Button>
                        {(isAiLoading || aiAnswer) && (
                            <div className="mt-4 p-4 rounded-md bg-background border text-sm whitespace-pre-wrap">
                                {isAiLoading ? <Skeleton className="h-20 w-full" /> : aiAnswer}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="transactions">
                <Card>
                    <CardHeader>
                        <CardTitle>Transaction Ledger</CardTitle>
                        <CardDescription>Complete list of transactions matching your filters.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Plate No.</TableHead>
                                    <TableHead>Type</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Entry / Exit</TableHead>
                                    <TableHead>Fee</TableHead>
                                    <TableHead>Payment</TableHead>
                                    <TableHead>Area</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredTransactions.length === 0 ? (
                                    <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No transactions found.</TableCell></TableRow>
                                ) : (
                                    filteredTransactions.sort((a,b) => new Date(b.waktu_masuk).getTime() - new Date(a.waktu_masuk).getTime()).map(t => {
                                        const vehicle = vehicles.find(v => v.id_kendaraan === t.id_kendaraan);
                                        const area = areas.find(a => a.id_area === t.id_area);
                                        return (
                                            <TableRow key={t.id_parkir}>
                                                <TableCell className="font-code font-bold">{vehicle?.plat_nomor}</TableCell>
                                                <TableCell>{vehicle?.jenis_kendaraan}</TableCell>
                                                <TableCell>
                                                    <Badge variant={t.status === 'selesai' ? 'default' : 'secondary'}>
                                                        {t.status === 'selesai' ? 'Paid' : 'Parked'}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell className="text-xs">
                                                    <div>In: {format(new Date(t.waktu_masuk), 'MMM dd, HH:mm')}</div>
                                                    {t.waktu_keluar && <div className="text-muted-foreground">Out: {format(new Date(t.waktu_keluar), 'MMM dd, HH:mm')}</div>}
                                                </TableCell>
                                                <TableCell className="font-semibold">{t.biaya_total ? `Rp ${t.biaya_total.toLocaleString()}` : '-'}</TableCell>
                                                <TableCell className="capitalize text-xs">{t.metode_pembayaran || '-'}</TableCell>
                                                <TableCell className="text-xs">{area?.nama_area}</TableCell>
                                            </TableRow>
                                        );
                                    })
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="logs">
                <Card>
                    <CardHeader>
                        <CardTitle>System Activity Audit</CardTitle>
                        <CardDescription>Track actions performed by Admin, Petugas, and Owner.</CardDescription>
                        <div className="pt-4 flex gap-4">
                            <div className="w-[200px] space-y-1">
                                <Label className="text-xs">User Filter</Label>
                                <Select value={logUserFilter} onValueChange={setLogUserFilter}>
                                    <SelectTrigger size="sm"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="all">All Users</SelectItem>
                                        {users.map(u => <SelectItem key={u.id_user} value={u.id_user.toString()}>{u.nama_lengkap} ({u.role})</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>User</TableHead>
                                    <TableHead>Activity</TableHead>
                                    <TableHead className="text-right">Timestamp</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredLogs.length === 0 ? (
                                    <TableRow><TableCell colSpan={3} className="text-center py-10 text-muted-foreground">No activity logs found.</TableCell></TableRow>
                                ) : (
                                    filteredLogs.sort((a,b) => new Date(b.waktu_aktivitas).getTime() - new Date(a.waktu_aktivitas).getTime()).map(log => {
                                        const user = users.find(u => u.id_user === log.id_user);
                                        return (
                                            <TableRow key={log.id_log}>
                                                <TableCell>
                                                    <div className="font-medium text-xs">{user?.nama_lengkap || 'System'}</div>
                                                    <div className="text-[10px] text-muted-foreground">{user?.role || ''}</div>
                                                </TableCell>
                                                <TableCell className="text-sm">{log.aktivitas}</TableCell>
                                                <TableCell className="text-right text-xs">
                                                    <div>{format(new Date(log.waktu_aktivitas), 'MMM dd, HH:mm:ss')}</div>
                                                    <div className="text-[10px] text-muted-foreground">{formatDistanceToNow(new Date(log.waktu_aktivitas), { addSuffix: true })}</div>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    })
                                )}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </TabsContent>
        </Tabs>
    </div>
  );
}
