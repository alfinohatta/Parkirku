'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format, formatDistanceToNow } from 'date-fns';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { useToast } from '@/hooks/use-toast';
import { Bar, BarChart, CartesianGrid, Tooltip, XAxis, YAxis, PieChart, Pie, Cell, Legend, Treemap } from 'recharts';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from '../ui/chart';

import type { User, Tariff, ParkingArea, Subscription, ActivityLog, VehicleType, Vehicle, Transaction } from '@/lib/types';
import { Building, DollarSign, Users, Tag, PlusCircle, Pencil, Trash2, CalendarIcon, History, Car, Bot } from 'lucide-react';
import { mockUsers, mockTariffs, mockParkingAreas, mockSubscriptions, mockActivityLogs, mockVehicles, mockTransactions } from '@/lib/data';
import { cn } from '@/lib/utils';
import { Textarea } from '../ui/textarea';
import usePersistentState from '@/hooks/use-persistent-state';
import LogoutButton from '../layout/logout-button';
import { getDailyOpsInsight } from '@/ai/flows/daily-ops-assistant-flow';
import type { DailyOpsInput } from '@/ai/types';
import { Skeleton } from '../ui/skeleton';
import { Label } from '../ui/label';

interface AdminDashboardProps {
  currentUser: User;
}

const areaChartConfig = {
  terisi: {
    label: 'Filled',
    color: 'hsl(var(--chart-1))',
  },
  sisa: {
    label: 'Available',
    color: 'hsl(var(--muted))',
  },
} satisfies ChartConfig;

const subscriptionChartConfig = {
  Active: {
    label: 'Active',
    color: 'hsl(var(--chart-1))',
  },
  Expired: {
    label: 'Expired',
    color: 'hsl(var(--chart-2))',
  },
} satisfies ChartConfig;

const treemapColors = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];

const CustomizedTreemapContent = (props: any) => {
  const { depth, x, y, width, height, index, name, value } = props;

  return (
    <g>
      <rect
        x={x}
        y={y}
        width={width}
        height={height}
        style={{
          fill: depth < 2 ? treemapColors[index % treemapColors.length] : 'none',
          stroke: '#fff',
          strokeWidth: 2 / (depth + 1e-10),
          strokeOpacity: 1 / (depth + 1e-10),
        }}
      />
      {depth === 2 && width > 50 && height > 25 ? (
        <text x={x + width / 2} y={y + height / 2 + 7} textAnchor="middle" fill="#fff" fontSize={14}>
          {name} ({value})
        </text>
      ) : null}
      {depth === 1 && width > 80 ? (
        <text x={x + 4} y={y + 18} fill="#fff" fontSize={16} fillOpacity={0.9}>
          {name}
        </text>
      ) : null}
    </g>
  );
};

export default function AdminDashboard({ currentUser }: AdminDashboardProps) {
  const { toast } = useToast();
  const [users, setUsers] = usePersistentState('users', mockUsers);
  const [tariffs, setTariffs] = usePersistentState('tariffs', mockTariffs);
  const [areas, setAreas] = usePersistentState('parkingAreas', mockParkingAreas);
  const [subscriptions, setSubscriptions] = usePersistentState('subscriptions', mockSubscriptions);
  const [activityLogs, setActivityLogs] = usePersistentState('activityLogs', mockActivityLogs);
  const [vehicles, setVehicles] = usePersistentState('vehicles', mockVehicles);
  const [transactions] = usePersistentState('transactions', mockTransactions);

  // Management State
  const [isUserDialogOpen, setUserDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isDeleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingUserId, setDeletingUserId] = useState<number | null>(null);
  
  const [isSubscriptionDialogOpen, setSubscriptionDialogOpen] = useState(false);
  const [editingSubscription, setEditingSubscription] = useState<Subscription | null>(null);
  const [isDeleteSubscriptionDialogOpen, setDeleteSubscriptionDialogOpen] = useState(false);
  const [deletingSubscriptionId, setDeletingSubscriptionId] = useState<number | null>(null);
  const [isToggleSubDialogOpen, setToggleSubDialogOpen] = useState(false);
  const [togglingSubscription, setTogglingSubscription] = useState<{ id: number; active: boolean } | null>(null);

  const [isTariffDialogOpen, setTariffDialogOpen] = useState(false);
  const [editingTariff, setEditingTariff] = useState<Tariff | null>(null);
  const [isDeleteTariffDialogOpen, setDeleteTariffDialogOpen] = useState(false);
  const [deletingTariffId, setDeletingTariffId] = useState<number | null>(null);

  const [isAreaDialogOpen, setAreaDialogOpen] = useState(false);
  const [editingArea, setEditingArea] = useState<ParkingArea | null>(null);
  const [isDeleteAreaDialogOpen, setDeleteAreaDialogOpen] = useState(false);
  const [deletingAreaId, setDeletingAreaId] = useState<number | null>(null);
  
  const [isVehicleDialogOpen, setVehicleDialogOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [isDeleteVehicleDialogOpen, setDeleteVehicleDialogOpen] = useState(false);
  const [deletingVehicleId, setDeletingVehicleId] = useState<number | null>(null);
  
  // AI State
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  // Filters
  const [userRoleFilter, setUserRoleFilter] = useState('all');
  const [subscriptionStatusFilter, setSubscriptionStatusFilter] = useState('all');
  const [vehicleTypeFilter, setVehicleTypeFilter] = useState('all');

  const userSchema = useMemo(() => z.object({
    nama_lengkap: z.string().min(3).max(50),
    username: z.string().min(3).max(20).refine(
        (val) => !users.some(u => u.username.toLowerCase() === val.toLowerCase() && u.id_user !== (editingUser?.id_user || 0)),
        { message: "Username already taken." }
    ),
    role: z.enum(['Admin', 'Petugas', 'Owner']),
    password: z.string().min(8).max(20).optional().or(z.literal('')),
  }), [users, editingUser]);

  const subscriptionSchema = useMemo(() => {
    const vehicleTypes = tariffs.map(t => t.jenis_kendaraan) as [string, ...string[]];
    return z.object({
        plat_nomor: z.string().min(3).max(15).toUpperCase().refine(
            (val) => !subscriptions.some(s => s.plat_nomor === val && s.id !== (editingSubscription?.id || 0)),
            { message: "A subscription for this plate number already exists." }
        ),
        jenis_kendaraan: z.enum(vehicleTypes.length > 0 ? vehicleTypes : ['']),
        tanggal_berakhir: z.date(),
  })}, [subscriptions, editingSubscription, tariffs]);
  
  const tariffSchema = useMemo(() => z.object({
    jenis_kendaraan: z.string().min(3).max(30).refine(
        (val) => !tariffs.some(t => t.jenis_kendaraan.toLowerCase() === val.toLowerCase() && t.id_tarif !== (editingTariff?.id_tarif || 0)),
        { message: 'This vehicle type already has a tariff.' }
    ),
    tarif_jam_pertama: z.coerce.number().min(0),
    tarif_per_jam: z.coerce.number().min(0),
    tarif_maks_harian: z.coerce.number().min(0),
  }), [tariffs, editingTariff]);
  
  const areaSchema = useMemo(() => z.object({
    nama_area: z.string().min(3).max(50).refine(
        (val) => !areas.some(a => a.nama_area.toLowerCase() === val.toLowerCase() && a.id_area !== (editingArea?.id_area || 0)),
        { message: "An area with this name already exists." }
    ),
    kapasitas: z.coerce.number().min(1),
  }), [areas, editingArea]);

  const vehicleSchema = z.object({
    pemilik: z.string().min(3).max(50),
    warna: z.string().min(3).max(30),
  });

  const userForm = useForm<z.infer<typeof userSchema>>({ resolver: zodResolver(userSchema) });
  const subscriptionForm = useForm<z.infer<typeof subscriptionSchema>>({ resolver: zodResolver(subscriptionSchema) });
  const tariffForm = useForm<z.infer<typeof tariffSchema>>({ resolver: zodResolver(tariffSchema) });
  const areaForm = useForm<z.infer<typeof areaSchema>>({ resolver: zodResolver(areaSchema) });
  const vehicleForm = useForm<z.infer<typeof vehicleSchema>>({ resolver: zodResolver(vehicleSchema) });

  useEffect(() => {
    if (isUserDialogOpen) {
      if (editingUser) userForm.reset({...editingUser, password: ''});
      else userForm.reset({ nama_lengkap: '', username: '', role: 'Petugas', password: '' });
    }
  }, [isUserDialogOpen, editingUser, userForm]);

  useEffect(() => {
    if(isSubscriptionDialogOpen) {
        if(editingSubscription) subscriptionForm.reset({ ...editingSubscription, tanggal_berakhir: new Date(editingSubscription.tanggal_berakhir) });
        else subscriptionForm.reset({ plat_nomor: '', jenis_kendaraan: undefined, tanggal_berakhir: undefined });
    }
  }, [isSubscriptionDialogOpen, editingSubscription, subscriptionForm]);

  useEffect(() => {
    if (isTariffDialogOpen) {
        if (editingTariff) tariffForm.reset(editingTariff);
        else tariffForm.reset({ jenis_kendaraan: '', tarif_jam_pertama: 0, tarif_per_jam: 0, tarif_maks_harian: 0 });
    }
  }, [isTariffDialogOpen, editingTariff, tariffForm]);

  useEffect(() => {
    if (isAreaDialogOpen) {
        if (editingArea) areaForm.reset(editingArea);
        else areaForm.reset({ nama_area: '', kapasitas: 10 });
    }
  }, [isAreaDialogOpen, editingArea, areaForm]);

  useEffect(() => {
    if(isVehicleDialogOpen && editingVehicle) {
        vehicleForm.reset({ pemilik: editingVehicle.pemilik, warna: editingVehicle.warna });
    }
  }, [isVehicleDialogOpen, editingVehicle, vehicleForm]);
  
  const addLog = (activity: string) => {
    const newLog: ActivityLog = {
        id_log: Date.now(),
        id_user: currentUser.id_user,
        aktivitas: activity,
        waktu_aktivitas: new Date().toISOString(),
    };
    setActivityLogs(prevLogs => [newLog, ...prevLogs]);
  };

  const handleSubscriptionToggle = () => {
    if (!togglingSubscription) return;
    const { id, active } = togglingSubscription;
    setSubscriptions(subscriptions.map((s) => (s.id === id ? { ...s, aktif: active } : s)));
    const sub = subscriptions.find(s => s.id === id);
    if (sub) {
        addLog(`Toggled subscription for ${sub.plat_nomor} to ${active ? 'Active' : 'Inactive'}.`);
        toast({ title: 'Subscription Status Updated', description: `Status for ${sub.plat_nomor} is now ${active ? 'Active' : 'Inactive'}`});
    }
    setToggleSubDialogOpen(false);
    setTogglingSubscription(null);
  };

  const handleSaveUser = (values: z.infer<typeof userSchema>) => {
    const { password, ...userData } = values;
    if (editingUser) {
      const updatedUser = { ...editingUser, ...userData, ...(password && { password_hash: password }) };
      setUsers(users.map((u) => (u.id_user === editingUser.id_user ? updatedUser : u)));
      addLog(`Updated user ${values.nama_lengkap}.`);
    } else {
      if (!password) {
        userForm.setError("password", { type: "manual", message: "Password is required for new users." });
        return;
      }
      const newId = users.length > 0 ? Math.max(...users.map((u) => u.id_user)) + 1 : 1;
      const newUser: User = { id_user: newId, ...userData, password_hash: password, status_aktif: true };
      setUsers((prevUsers) => [...prevUsers, newUser]);
      addLog(`Added new user ${values.nama_lengkap}.`);
    }
    setUserDialogOpen(false);
  };

  const handleDeleteUser = () => {
    if (deletingUserId) {
      const user = users.find(u => u.id_user === deletingUserId);
      setUsers(users.filter((u) => u.id_user !== deletingUserId));
      addLog(`Deleted user ${user?.nama_lengkap || ''}.`);
      setDeleteDialogOpen(false);
      setDeletingUserId(null);
    }
  };

  const handleSaveSubscription = (values: z.infer<typeof subscriptionSchema>) => {
    if (editingSubscription) {
      setSubscriptions(subscriptions.map((s) => s.id === editingSubscription.id ? { ...s, ...values, tanggal_berakhir: values.tanggal_berakhir.toISOString() } : s));
      addLog(`Updated subscription for ${values.plat_nomor}.`);
    } else {
      const newId = subscriptions.length > 0 ? Math.max(...subscriptions.map((s) => s.id)) + 1 : 1;
      const newSubscription: Subscription = {
        id: newId, plat_nomor: values.plat_nomor, jenis_kendaraan: values.jenis_kendaraan as VehicleType,
        tanggal_aktivasi: new Date().toISOString(), tanggal_berakhir: values.tanggal_berakhir.toISOString(),
        aktif: values.tanggal_berakhir >= new Date(),
      };
      setSubscriptions([...subscriptions, newSubscription]);
      addLog(`Added new subscription for ${values.plat_nomor}.`);
    }
    setSubscriptionDialogOpen(false);
  };
  
  const handleDeleteSubscription = () => {
      if (deletingSubscriptionId) {
          const sub = subscriptions.find(s => s.id === deletingSubscriptionId);
          setSubscriptions(subscriptions.filter(s => s.id !== deletingSubscriptionId));
          addLog(`Deleted subscription for ${sub?.plat_nomor || ''}.`);
          setDeleteSubscriptionDialogOpen(false);
          setDeletingSubscriptionId(null);
      }
  };

  const handleSaveTariff = (values: z.infer<typeof tariffSchema>) => {
    if (editingTariff) {
        setTariffs(tariffs.map(t => t.id_tarif === editingTariff.id_tarif ? { ...t, ...values } : t));
        addLog(`Updated tariff for ${values.jenis_kendaraan}.`);
    } else {
        const newId = tariffs.length > 0 ? Math.max(...tariffs.map(t => t.id_tarif)) + 1 : 1;
        setTariffs([...tariffs, { id_tarif: newId, ...values }]);
        addLog(`Added new tariff for ${values.jenis_kendaraan}.`);
    }
    setTariffDialogOpen(false);
  };

  const handleDeleteTariff = () => {
      if(deletingTariffId) {
          const tariff = tariffs.find(t => t.id_tarif === deletingTariffId);
          setTariffs(tariffs.filter(t => t.id_tarif !== deletingTariffId));
          addLog(`Deleted tariff for ${tariff?.jenis_kendaraan || ''}.`);
          setDeleteTariffDialogOpen(false);
          setDeletingTariffId(null);
      }
  };

  const handleSaveArea = (values: z.infer<typeof areaSchema>) => {
      if (editingArea) {
          setAreas(areas.map(a => a.id_area === editingArea.id_area ? { ...a, ...values } : a));
          addLog(`Updated parking area ${values.nama_area}.`);
      } else {
          const newId = areas.length > 0 ? Math.max(...areas.map(a => a.id_area)) + 1 : 1;
          setAreas([...areas, { id_area: newId, ...values, terisi: 0 }]);
          addLog(`Added new parking area ${values.nama_area}.`);
      }
      setAreaDialogOpen(false);
  };

  const handleDeleteArea = () => {
      if(deletingAreaId) {
          const area = areas.find(a => a.id_area === deletingAreaId);
          setAreas(areas.filter(a => a.id_area !== deletingAreaId));
          addLog(`Deleted parking area ${area?.nama_area || ''}.`);
          setDeleteAreaDialogOpen(false);
          setDeletingAreaId(null);
      }
  };
    
  const handleSaveVehicle = (values: z.infer<typeof vehicleSchema>) => {
      if (editingVehicle) {
          setVehicles(vehicles.map(v => v.id_kendaraan === editingVehicle.id_kendaraan ? { ...v, ...values } : v));
          addLog(`Updated vehicle ${editingVehicle.plat_nomor}.`);
      }
      setVehicleDialogOpen(false);
  };
    
  const handleDeleteVehicle = () => {
      if (deletingVehicleId) {
          const isVehicleInUse = transactions.some((t: Transaction) => t.id_kendaraan === deletingVehicleId);
          if (isVehicleInUse) {
              toast({ variant: "destructive", title: "Deletion Failed", description: "Cannot delete a vehicle with transaction history." });
              setDeleteVehicleDialogOpen(false);
              setDeletingVehicleId(null);
              return;
          }
          const vehicle = vehicles.find((v: Vehicle) => v.id_kendaraan === deletingVehicleId);
          setVehicles(vehicles.filter((v: Vehicle) => v.id_kendaraan !== deletingVehicleId));
          addLog(`Deleted vehicle ${vehicle?.plat_nomor || ''}.`);
          setDeleteVehicleDialogOpen(false);
          setDeletingVehicleId(null);
      }
  };
    
  const handleAskAi = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!aiQuestion.trim()) return;
      setIsAiLoading(true);
      setAiAnswer('');
      try {
          const today = new Date(); today.setHours(0, 0, 0, 0);
          const todayTransactions = transactions.filter((t: Transaction) => new Date(t.waktu_masuk) >= today);
          const input: DailyOpsInput = {
              question: aiQuestion,
              todayTransactions: JSON.stringify(todayTransactions),
              users: JSON.stringify(users),
              parkingAreas: JSON.stringify(areas),
              currentUser: JSON.stringify(currentUser),
          };
          const answer = await getDailyOpsInsight(input);
          setAiAnswer(answer);
      } catch (error) {
          setAiAnswer('Error processing AI request.');
      } finally {
          setIsAiLoading(false);
      }
  };

  const filteredUsers = useMemo(() => users.filter(user => userRoleFilter === 'all' || user.role === userRoleFilter), [users, userRoleFilter]);
  const filteredSubscriptions = useMemo(() => subscriptions.filter(sub => subscriptionStatusFilter === 'all' ? true : (subscriptionStatusFilter === 'active' ? sub.aktif : !sub.aktif)), [subscriptions, subscriptionStatusFilter]);
  const filteredVehicles = useMemo(() => vehicles.filter(vehicle => vehicleTypeFilter === 'all' || vehicle.jenis_kendaraan === vehicleTypeFilter), [vehicles, vehicleTypeFilter]);

  const subscriptionStatusData = [
    { name: 'Active', value: subscriptions.filter((s) => s.aktif).length },
    { name: 'Expired', value: subscriptions.filter((s) => !s.aktif).length },
  ];

  const chartDataAreas = areas.map((area) => ({ ...area, sisa: area.kapasitas - area.terisi }));

  const treemapData = useMemo(() => {
    const parkedVehicles = transactions.filter(t => t.status === 'di_dalam');
    return areas.map(area => {
      const vehiclesInArea = parkedVehicles.filter(t => t.id_area === area.id_area);
      const vehicleTypes = vehiclesInArea.reduce((acc, t) => {
        const v = vehicles.find(v => v.id_kendaraan === t.id_kendaraan);
        if (v) acc[v.jenis_kendaraan] = (acc[v.jenis_kendaraan] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      return { name: area.nama_area, children: Object.entries(vehicleTypes).map(([name, size]) => ({ name, size })) };
    }).filter(area => area.children.length > 0);
  }, [transactions, vehicles, areas]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
            <h1 className="text-3xl font-bold tracking-tight">Welcome, {currentUser.nama_lengkap}</h1>
            <p className="text-muted-foreground">System management overview.</p>
        </div>
        <LogoutButton currentUser={currentUser} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Area Occupancy</CardTitle></CardHeader>
          <CardContent className="h-[250px]">
            <ChartContainer config={areaChartConfig} className="w-full h-full">
              <BarChart data={chartDataAreas} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="nama_area" width={100} tickLine={false} axisLine={false} />
                <Tooltip content={<ChartTooltipContent />} />
                <Bar dataKey="terisi" fill="var(--color-terisi)" radius={[0, 4, 4, 0]} stackId="a" />
                <Bar dataKey="sisa" fill="var(--color-sisa)" radius={[0, 4, 4, 0]} stackId="a" />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Subscriptions</CardTitle></CardHeader>
          <CardContent className="h-[250px] flex items-center justify-center">
            <ChartContainer config={subscriptionChartConfig} className="w-full h-full">
              <PieChart>
                <Pie data={subscriptionStatusData} cx="50%" cy="50%" label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`} outerRadius={80} dataKey="value" nameKey="name">
                  {subscriptionStatusData.map((e, i) => <Cell key={i} fill={`var(--color-${e.name})`} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5" /> Operations Assistant</CardTitle></CardHeader>
        <CardContent>
            <form onSubmit={handleAskAi} className="space-y-4">
                <Textarea placeholder="Ask AI about operations..." value={aiQuestion} onChange={(e) => setAiQuestion(e.target.value)} disabled={isAiLoading} maxLength={200} />
                <Button type="submit" disabled={isAiLoading}>{isAiLoading ? 'Thinking...' : 'Ask AI'}</Button>
            </form>
        </CardContent>
        {(isAiLoading || aiAnswer) && (
            <CardFooter>
                <div className="w-full p-4 bg-muted/50 rounded-md text-sm">
                    {isAiLoading ? <Skeleton className="h-20 w-full" /> : <p className="whitespace-pre-wrap">{aiAnswer}</p>}
                </div>
            </CardFooter>
        )}
      </Card>

      <Card>
        <CardHeader><CardTitle>Management</CardTitle></CardHeader>
        <CardContent>
          <Tabs defaultValue="users" className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="tariffs">Tariffs</TabsTrigger>
              <TabsTrigger value="areas">Areas</TabsTrigger>
              <TabsTrigger value="subscriptions">Subs</TabsTrigger>
              <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
              <TabsTrigger value="logs">Logs</TabsTrigger>
            </TabsList>

            <TabsContent value="users" className="mt-4">
              <div className="flex justify-between items-center mb-4">
                <Select value={userRoleFilter} onValueChange={setUserRoleFilter}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="Admin">Admin</SelectItem>
                    <SelectItem value="Petugas">Petugas</SelectItem>
                    <SelectItem value="Owner">Owner</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={() => { setEditingUser(null); setUserDialogOpen(true); }}>Add User</Button>
              </div>
              <Table>
                <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>User</TableHead><TableHead>Role</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {filteredUsers.map((u) => (
                    <TableRow key={u.id_user}>
                      <TableCell>{u.nama_lengkap}</TableCell>
                      <TableCell>{u.username}</TableCell>
                      <TableCell><Badge variant="outline">{u.role}</Badge></TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingUser(u); setUserDialogOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => { setDeletingUserId(u.id_user); setDeleteDialogOpen(true); }}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="tariffs" className="mt-4">
              <div className="flex justify-end mb-4">
                <Button onClick={() => { setEditingTariff(null); setTariffDialogOpen(true); }}>Add Tariff</Button>
              </div>
              <Table>
                <TableHeader><TableRow><TableHead>Vehicle</TableHead><TableHead>First Hr</TableHead><TableHead>Next Hr</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {tariffs.map((t) => (
                    <TableRow key={t.id_tarif}>
                      <TableCell>{t.jenis_kendaraan}</TableCell>
                      <TableCell>Rp {t.tarif_jam_pertama.toLocaleString()}</TableCell>
                      <TableCell>Rp {t.tarif_per_jam.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingTariff(t); setTariffDialogOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => { setDeletingTariffId(t.id_tarif); setDeleteTariffDialogOpen(true); }}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="areas" className="mt-4">
              <div className="flex justify-end mb-4">
                <Button onClick={() => { setEditingArea(null); setAreaDialogOpen(true); }}>Add Area</Button>
              </div>
              <Table>
                <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Cap</TableHead><TableHead>Filled</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {areas.map((a) => (
                    <TableRow key={a.id_area}>
                      <TableCell>{a.nama_area}</TableCell>
                      <TableCell>{a.kapasitas}</TableCell>
                      <TableCell>{a.terisi}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingArea(a); setAreaDialogOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => { setDeletingAreaId(a.id_area); setDeleteAreaDialogOpen(true); }}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="subscriptions" className="mt-4">
              <div className="flex justify-between items-center mb-4">
                <Select value={subscriptionStatusFilter} onValueChange={setSubscriptionStatusFilter}>
                  <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={() => { setEditingSubscription(null); setSubscriptionDialogOpen(true); }}>Add Sub</Button>
              </div>
              <Table>
                <TableHeader><TableRow><TableHead>Plate</TableHead><TableHead>Type</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {filteredSubscriptions.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-code">{s.plat_nomor}</TableCell>
                      <TableCell>{s.jenis_kendaraan}</TableCell>
                      <TableCell><Badge variant={s.aktif ? 'default' : 'destructive'}>{s.aktif ? 'Active' : 'Expired'}</Badge></TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingSubscription(s); setSubscriptionDialogOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => { setDeletingSubscriptionId(s.id); setDeleteSubscriptionDialogOpen(true); }}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="vehicles" className="mt-4">
              <Table>
                <TableHeader><TableRow><TableHead>Plate</TableHead><TableHead>Owner</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {filteredVehicles.map((v) => (
                    <TableRow key={v.id_kendaraan}>
                      <TableCell className="font-code">{v.plat_nomor}</TableCell>
                      <TableCell>{v.pemilik}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => { setEditingVehicle(v); setVehicleDialogOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => { setDeletingVehicleId(v.id_kendaraan); setDeleteVehicleDialogOpen(true); }}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="logs" className="mt-4">
              <Table>
                <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Activity</TableHead><TableHead className="text-right">Time</TableHead></TableRow></TableHeader>
                <TableBody>
                  {activityLogs.slice(0, 50).map((l) => {
                    const u = users.find(user => user.id_user === l.id_user);
                    return (
                      <TableRow key={l.id_log}>
                        <TableCell>{u?.nama_lengkap || 'System'}</TableCell>
                        <TableCell>{l.aktivitas}</TableCell>
                        <TableCell className="text-right text-xs">{format(new Date(l.waktu_aktivitas), 'dd MMM, HH:mm')}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>

          {/* Dialogs */}
          <Dialog open={isUserDialogOpen} onOpenChange={setUserDialogOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>{editingUser ? 'Edit User' : 'Add User'}</DialogTitle></DialogHeader>
              <Form {...userForm}><form onSubmit={userForm.handleSubmit(handleSaveUser)} className="space-y-4">
                <FormField control={userForm.control} name="nama_lengkap" render={({ field }) => (
                  <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input {...field} maxLength={50} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={userForm.control} name="username" render={({ field }) => (
                  <FormItem><FormLabel>Username</FormLabel><FormControl><Input {...field} maxLength={20} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={userForm.control} name="password" render={({ field }) => (
                  <FormItem><FormLabel>Password</FormLabel><FormControl><Input type="password" {...field} maxLength={20} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={userForm.control} name="role" render={({ field }) => (
                  <FormItem><FormLabel>Role</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl><SelectContent><SelectItem value="Admin">Admin</SelectItem><SelectItem value="Petugas">Petugas</SelectItem><SelectItem value="Owner">Owner</SelectItem></SelectContent></Select><FormMessage /></FormItem>
                )} />
                <DialogFooter><Button type="submit">Save</Button></DialogFooter>
              </form></Form>
            </DialogContent>
          </Dialog>

          <Dialog open={isSubscriptionDialogOpen} onOpenChange={setSubscriptionDialogOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Subscription</DialogTitle></DialogHeader>
              <Form {...subscriptionForm}><form onSubmit={subscriptionForm.handleSubmit(handleSaveSubscription)} className="space-y-4">
                <FormField control={subscriptionForm.control} name="plat_nomor" render={({ field }) => (
                  <FormItem><FormLabel>Plate No</FormLabel><FormControl><Input {...field} maxLength={15} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={subscriptionForm.control} name="jenis_kendaraan" render={({ field }) => (
                  <FormItem><FormLabel>Type</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl><SelectContent>{tariffs.map(t => <SelectItem key={t.id_tarif} value={t.jenis_kendaraan}>{t.jenis_kendaraan}</SelectItem>)}</SelectContent></Select><FormMessage /></FormItem>
                )} />
                <FormField control={subscriptionForm.control} name="tanggal_berakhir" render={({ field }) => (
                  <FormItem className="flex flex-col"><FormLabel>End Date</FormLabel><Popover><PopoverTrigger asChild><Button variant="outline">{field.value ? format(field.value, 'PPP') : 'Pick Date'}</Button></PopoverTrigger><PopoverContent><Calendar mode="single" selected={field.value} onSelect={field.onChange} /></PopoverContent></Popover><FormMessage /></FormItem>
                )} />
                <DialogFooter><Button type="submit">Save</Button></DialogFooter>
              </form></Form>
            </DialogContent>
          </Dialog>

          <Dialog open={isTariffDialogOpen} onOpenChange={setTariffDialogOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Tariff</DialogTitle></DialogHeader>
              <Form {...tariffForm}><form onSubmit={tariffForm.handleSubmit(handleSaveTariff)} className="space-y-4">
                <FormField control={tariffForm.control} name="jenis_kendaraan" render={({ field }) => (
                  <FormItem><FormLabel>Vehicle Type</FormLabel><FormControl><Input {...field} maxLength={30} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={tariffForm.control} name="tarif_jam_pertama" render={({ field }) => (
                  <FormItem><FormLabel>First Hour</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={tariffForm.control} name="tarif_per_jam" render={({ field }) => (
                  <FormItem><FormLabel>Next Hour</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={tariffForm.control} name="tarif_maks_harian" render={({ field }) => (
                  <FormItem><FormLabel>Max Daily</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <DialogFooter><Button type="submit">Save</Button></DialogFooter>
              </form></Form>
            </DialogContent>
          </Dialog>

          <Dialog open={isAreaDialogOpen} onOpenChange={setAreaDialogOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Area</DialogTitle></DialogHeader>
              <Form {...areaForm}><form onSubmit={areaForm.handleSubmit(handleSaveArea)} className="space-y-4">
                <FormField control={areaForm.control} name="nama_area" render={({ field }) => (
                  <FormItem><FormLabel>Area Name</FormLabel><FormControl><Input {...field} maxLength={50} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={areaForm.control} name="kapasitas" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Capacity</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <DialogFooter><Button type="submit">Save</Button></DialogFooter>
              </form></Form>
            </DialogContent>
          </Dialog>

          <Dialog open={isVehicleDialogOpen} onOpenChange={setVehicleDialogOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Vehicle</DialogTitle></DialogHeader>
              <Form {...vehicleForm}><form onSubmit={vehicleForm.handleSubmit(handleSaveVehicle)} className="space-y-4">
                <FormField control={vehicleForm.control} name="pemilik" render={({ field }) => (
                  <FormItem><FormLabel>Owner</FormLabel><FormControl><Input {...field} maxLength={50} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={vehicleForm.control} name="warna" render={({ field }) => (
                  <FormItem><FormLabel>Color</FormLabel><FormControl><Input {...field} maxLength={30} /></FormControl><FormMessage /></FormItem>
                )} />
                <DialogFooter><Button type="submit">Save</Button></DialogFooter>
              </form></Form>
            </DialogContent>
          </Dialog>

          <AlertDialog open={isDeleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete User?</AlertDialogTitle></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDeleteUser}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
          </AlertDialog>
          <AlertDialog open={isDeleteSubscriptionDialogOpen} onOpenChange={setDeleteSubscriptionDialogOpen}>
            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete Sub?</AlertDialogTitle></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDeleteSubscription}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
          </AlertDialog>
          <AlertDialog open={isDeleteTariffDialogOpen} onOpenChange={setDeleteTariffDialogOpen}>
            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete Tariff?</AlertDialogTitle></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDeleteTariff}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
          </AlertDialog>
          <AlertDialog open={isDeleteAreaDialogOpen} onOpenChange={setDeleteAreaDialogOpen}>
            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete Area?</AlertDialogTitle></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDeleteArea}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
          </AlertDialog>
          <AlertDialog open={isDeleteVehicleDialogOpen} onOpenChange={setDeleteVehicleDialogOpen}>
            <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Delete Vehicle?</AlertDialogTitle></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDeleteVehicle}>Delete</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
    </div>
  );
}
