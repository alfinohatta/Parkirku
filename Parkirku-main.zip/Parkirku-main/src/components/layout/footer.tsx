import Link from 'next/link';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-background border-t print:hidden">
      <div className="container flex flex-col md:flex-row items-center justify-between gap-4 py-8 px-4 mx-auto">
        <div className="flex flex-col gap-1">
           <p className="text-[10px] font-black uppercase tracking-widest text-foreground">
            ParkRight Enterprise
          </p>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">
            &copy; {currentYear} Secure Operations System
          </p>
        </div>
        <nav className="flex gap-6">
            <Link href="#" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
                Privacy
            </Link>
            <Link href="#" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
                Terms
            </Link>
             <Link href="#" className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
                Support
            </Link>
        </nav>
      </div>
    </footer>
  );
}