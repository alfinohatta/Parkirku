'use client';

import Link from 'next/link';
import { Car } from 'lucide-react';
import UserNav from './user-nav';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 print:hidden">
      <div className="container flex h-16 items-center px-4 mx-auto">
        <div className="mr-auto flex items-center">
          <Link 
            href="/" 
            className="group flex items-center gap-3 transition-all duration-300"
          >
            <div className="relative flex items-center justify-center w-10 h-10 bg-foreground rounded-lg shadow-sm group-hover:bg-primary transition-colors duration-300">
              <Car className="h-5 w-5 text-background" />
            </div>

            <div className="flex flex-col -space-y-1">
              <span className="font-headline text-xl font-black tracking-tighter text-foreground uppercase">
                Park<span className="text-primary">Right</span>
              </span>
              <span className="text-[9px] font-black uppercase tracking-[0.3em] text-muted-foreground">
                Enterprise
              </span>
            </div>
          </Link>
        </div>
        
        <div className="flex items-center justify-end">
          <UserNav />
        </div>
      </div>
    </header>
  );
}
