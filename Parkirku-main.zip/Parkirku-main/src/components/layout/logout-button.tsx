'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { User } from '@/lib/types';

interface LogoutButtonProps {
    currentUser: User | null;
    className?: string;
}

export default function LogoutButton({ currentUser, className }: LogoutButtonProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [isLogoutAlertOpen, setLogoutAlertOpen] = useState(false);

  const handleLogout = () => {
    const userName = currentUser?.nama_lengkap || 'User';
    localStorage.removeItem('currentUser');
    toast({
        title: 'Logged Out',
        description: `Goodbye, ${userName}.`,
    });
    router.push('/login');
  };

  return (
    <>
      <Button variant="outline" className={className} onClick={() => setLogoutAlertOpen(true)}>
        <LogOut className="mr-2 h-4 w-4" />
        Log Out
      </Button>

      <AlertDialog open={isLogoutAlertOpen} onOpenChange={setLogoutAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to log out?</AlertDialogTitle>
            <AlertDialogDescription>
              This will end your current session and you will need to log in again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleLogout}>Log Out</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
