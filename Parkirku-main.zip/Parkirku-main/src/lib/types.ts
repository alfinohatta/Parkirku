export type Role = 'Admin' | 'Petugas' | 'Owner';

export interface User {
  id_user: number;
  nama_lengkap: string;
  username: string;
  role: Role;
  password_hash?: string; // Optional for client-side
  status_aktif?: boolean; // Optional for client-side
}

export type VehicleType = string;

export interface Vehicle {
  id_kendaraan: number;
  plat_nomor: string;
  jenis_kendaraan: VehicleType;
  pemilik: string;
  warna: string;
  id_user?: number; // Optional based on ERD
}

export interface ParkingArea {
  id_area: number;
  nama_area: string;
  kapasitas: number;
  terisi: number;
}

export interface Tariff {
  id_tarif: number;
  jenis_kendaraan: VehicleType;
  tarif_jam_pertama: number;
  tarif_per_jam: number;
  tarif_maks_harian: number;
}

export interface Subscription {
  id: number;
  plat_nomor: string;
  jenis_kendaraan: VehicleType;
  tanggal_aktivasi: string;
  tanggal_berakhir: string;
  aktif: boolean;
}

export interface Transaction {
  id_parkir: number;
  id_kendaraan: number;
  waktu_masuk: string;
  waktu_keluar: string | null;
  id_tarif: number;
  id_area: number;
  status: 'di_dalam' | 'selesai' | 'dibatalkan';
  id_petugas_masuk: number;
  id_petugas_keluar: number | null;
  durasi_jam: number | null;
  biaya_total: number | null;
  metode_pembayaran: 'tunai' | 'qris' | 'debit' | 'member' | 'override' | null;
  alasan_override?: string | null;
}

export interface ActivityLog {
  id_log: number;
  id_user: number;
  aktivitas: string;
  waktu_aktivitas: string;
}
