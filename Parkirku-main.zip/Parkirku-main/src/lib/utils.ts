import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { Tariff, Transaction } from './types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function calculateFee(
  transaction: Pick<Transaction, 'waktu_masuk' | 'waktu_keluar' | 'id_tarif'>,
  tariffs: Tariff[],
  isMember: boolean = false
): { totalFee: number; durationHours: number } {
  if (!transaction.waktu_keluar) {
    return { totalFee: 0, durationHours: 0 };
  }

  const durationMinutes = (new Date(transaction.waktu_keluar).getTime() - new Date(transaction.waktu_masuk).getTime()) / (1000 * 60);

  // Apply a 5-minute grace period for everyone.
  if (durationMinutes <= 5) {
    return { totalFee: 0, durationHours: 0 };
  }

  const durationHours = Math.ceil(durationMinutes / 60);

  // For members, the fee is always 0, but the duration is calculated correctly.
  if (isMember) {
    return { totalFee: 0, durationHours };
  }

  const tariff = tariffs.find(t => t.id_tarif === transaction.id_tarif);

  if (!tariff) {
    return { totalFee: 0, durationHours };
  }

  let totalFee = 0;
  if (durationHours > 0) {
      totalFee = tariff.tarif_jam_pertama;
      if (durationHours > 1) {
          totalFee += (durationHours - 1) * tariff.tarif_per_jam;
      }
  }

  // Apply daily max tariff if it's exceeded
  if (tariff.tarif_maks_harian > 0) {
    totalFee = Math.min(totalFee, tariff.tarif_maks_harian);
  }

  return { totalFee, durationHours };
}
