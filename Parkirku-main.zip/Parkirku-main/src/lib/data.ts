import type { User, Vehicle, ParkingArea, Tariff, Transaction, Subscription, ActivityLog } from './types';

export const mockUsers: User[] = [
  { id_user: 1, nama_lengkap: 'Admin ParkRight', username: 'admin', role: 'Admin', status_aktif: true, password_hash: 'password123' },
  { id_user: 2, nama_lengkap: 'Budi Petugas', username: 'petugas1', role: 'Petugas', status_aktif: true, password_hash: 'password123' },
  { id_user: 3, nama_lengkap: 'John Doe', username: 'owner', role: 'Owner', status_aktif: true, password_hash: 'password123' },
  { id_user: 4, nama_lengkap: 'Siti Petugas', username: 'petugas2', role: 'Petugas', status_aktif: true, password_hash: 'password123' },
];

export const mockVehicles: Vehicle[] = [
  { id_kendaraan: 1, plat_nomor: 'B 1234 ABC', jenis_kendaraan: 'Mobil', pemilik: 'John Doe', warna: 'Hitam' },
  { id_kendaraan: 2, plat_nomor: 'D 5678 XYZ', jenis_kendaraan: 'Motor', pemilik: 'Jane Smith', warna: 'Merah' },
  { id_kendaraan: 3, plat_nomor: 'F 9101 GHI', jenis_kendaraan: 'Mobil', pemilik: 'Member Langganan', warna: 'Putih' },
  { id_kendaraan: 4, plat_nomor: 'A 2345 JKL', jenis_kendaraan: 'Motor', pemilik: 'Budi Santoso', warna: 'Biru' },
  { id_kendaraan: 5, plat_nomor: 'B 6789 MNO', jenis_kendaraan: 'Mobil', pemilik: 'Siti Aminah', warna: 'Silver' },
  { id_kendaraan: 6, plat_nomor: 'Z 1111 WWW', jenis_kendaraan: 'Motor', pemilik: 'Alex', warna: 'Hijau' },
  { id_kendaraan: 7, plat_nomor: 'B 9876 BOX', jenis_kendaraan: 'Mobil Box', pemilik: 'PT. Kargo Cepat', warna: 'Kuning' },
];

export const mockParkingAreas: ParkingArea[] = [
  { id_area: 1, nama_area: 'Basement 1', kapasitas: 50, terisi: 3 },
  { id_area: 2, nama_area: 'Area Terbuka A', kapasitas: 100, terisi: 1 },
  { id_area: 3, nama_area: 'Gedung Parkir Lt. 3', kapasitas: 75, terisi: 0 },
];

export const mockTariffs: Tariff[] = [
  { id_tarif: 1, jenis_kendaraan: 'Motor', tarif_jam_pertama: 2000, tarif_per_jam: 1000, tarif_maks_harian: 8000 },
  { id_tarif: 2, jenis_kendaraan: 'Mobil', tarif_jam_pertama: 5000, tarif_per_jam: 3000, tarif_maks_harian: 25000 },
  { id_tarif: 3, jenis_kendaraan: 'Mobil Box', tarif_jam_pertama: 8000, tarif_per_jam: 5000, tarif_maks_harian: 50000 },
  { id_tarif: 4, jenis_kendaraan: 'Valet', tarif_jam_pertama: 50000, tarif_per_jam: 0, tarif_maks_harian: 50000 },
];

export const mockSubscriptions: Subscription[] = [
  { id: 1, plat_nomor: 'F 9101 GHI', jenis_kendaraan: 'Mobil', tanggal_aktivasi: '2024-07-01', tanggal_berakhir: '2024-07-31', aktif: true },
  { id: 2, plat_nomor: 'X 9999 XXX', jenis_kendaraan: 'Motor', tanggal_aktivasi: '2024-06-15', tanggal_berakhir: '2024-07-15', aktif: false },
];

const now = new Date();
const twoHoursAgo = new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString();
const fourHoursAgo = new Date(now.getTime() - 4 * 60 * 60 * 1000).toISOString();
const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

export const mockTransactions: Transaction[] = [
  {
    id_parkir: 1,
    id_kendaraan: 1,
    waktu_masuk: twoHoursAgo,
    waktu_keluar: null,
    id_tarif: 2, // Mobil
    id_area: 1,
    status: 'di_dalam',
    id_petugas_masuk: 2,
    id_petugas_keluar: null,
    durasi_jam: null,
    biaya_total: null,
    metode_pembayaran: null,
  },
  {
    id_parkir: 2,
    id_kendaraan: 2,
    waktu_masuk: new Date(now.getTime() - 45 * 60 * 1000).toISOString(),
    waktu_keluar: null,
    id_tarif: 1, // Motor
    id_area: 2,
    status: 'di_dalam',
    id_petugas_masuk: 4,
    id_petugas_keluar: null,
    durasi_jam: null,
    biaya_total: null,
    metode_pembayaran: null,
  },
  {
    id_parkir: 3,
    id_kendaraan: 3,
    waktu_masuk: fourHoursAgo,
    waktu_keluar: null,
    id_tarif: 2, // Mobil
    id_area: 1,
    status: 'di_dalam',
    id_petugas_masuk: 2,
    id_petugas_keluar: null,
    durasi_jam: null,
    biaya_total: null,
    metode_pembayaran: null,
  },
  {
    id_parkir: 4,
    id_kendaraan: 4,
    waktu_masuk: new Date(oneDayAgo.getTime() + 2 * 60 * 60 * 1000).toISOString(), // Yesterday + 2 hours
    waktu_keluar: new Date(oneDayAgo.getTime() + 5 * 60 * 60 * 1000).toISOString(), // Yesterday + 5 hours (3hr duration)
    id_tarif: 1, // Motor
    id_area: 2,
    status: 'selesai',
    id_petugas_masuk: 2,
    id_petugas_keluar: 2,
    durasi_jam: 3,
    biaya_total: 4000, // 2000 + (2 * 1000)
    metode_pembayaran: 'tunai',
  },
  {
    id_parkir: 5,
    id_kendaraan: 5,
    waktu_masuk: new Date(oneDayAgo.getTime()).toISOString(), // Yesterday
    waktu_keluar: new Date(oneDayAgo.getTime() + 10 * 60 * 60 * 1000).toISOString(), // Yesterday + 10 hours
    id_tarif: 2, // Mobil
    id_area: 3,
    status: 'selesai',
    id_petugas_masuk: 4,
    id_petugas_keluar: 4,
    durasi_jam: 10,
    biaya_total: 25000, // Capped at max daily
    metode_pembayaran: 'qris',
  },
  {
    id_parkir: 6,
    id_kendaraan: 6,
    waktu_masuk: new Date(oneDayAgo.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    waktu_keluar: new Date(oneDayAgo.getTime() - 2 * 24 * 60 * 60 * 1000 + 40 * 60 * 1000).toISOString(), // 2 days ago + 40m
    id_tarif: 1, // Motor
    id_area: 1,
    status: 'selesai',
    id_petugas_masuk: 2,
    id_petugas_keluar: 2,
    durasi_jam: 1,
    biaya_total: 2000, // First hour
    metode_pembayaran: 'debit',
  },
  {
    id_parkir: 7,
    id_kendaraan: 7,
    waktu_masuk: new Date(now.getTime() - 8 * 60 * 60 * 1000).toISOString(),
    waktu_keluar: null,
    id_tarif: 3, // Mobil Box
    id_area: 1,
    status: 'di_dalam',
    id_petugas_masuk: 4,
    id_petugas_keluar: null,
    durasi_jam: null,
    biaya_total: null,
    metode_pembayaran: null,
  },
  {
    id_parkir: 8,
    id_kendaraan: 1,
    waktu_masuk: new Date(oneDayAgo.getTime() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    waktu_keluar: new Date(oneDayAgo.getTime() - 3 * 24 * 60 * 60 * 1000 + (3 * 60 + 10) * 60 * 1000).toISOString(), // 3h 10m -> 4h
    id_tarif: 2, // Mobil
    id_area: 3,
    status: 'selesai',
    id_petugas_masuk: 4,
    id_petugas_keluar: 4,
    durasi_jam: 4,
    biaya_total: 14000, // 5000 + (3 * 3000)
    metode_pembayaran: 'tunai',
  },
];


export const mockActivityLogs: ActivityLog[] = [
    { id_log: 1, id_user: 3, aktivitas: "Logged in.", waktu_aktivitas: new Date(now.getTime() - 20 * 60 * 1000).toISOString() },
    { id_log: 2, id_user: 1, aktivitas: "Logged in.", waktu_aktivitas: new Date(now.getTime() - 18 * 60 * 1000).toISOString() },
    { id_log: 3, id_user: 2, aktivitas: "Checked in vehicle D 5678 XYZ.", waktu_aktivitas: new Date(now.getTime() - 45 * 60 * 1000).toISOString() },
    { id_log: 4, id_user: 4, aktivitas: "Checked in vehicle B 1234 ABC.", waktu_aktivitas: twoHoursAgo },
    { id_log: 5, id_user: 1, aktivitas: "Added new user 'Siti Petugas'.", waktu_aktivitas: new Date(now.getTime() - 30 * 60 * 1000).toISOString() },
    { id_log: 6, id_user: 2, aktivitas: "Checked out vehicle A 2345 JKL with payment 'tunai' for Rp 3,000.", waktu_aktivitas: new Date(now.getTime() - 15 * 60 * 1000).toISOString() },
    { id_log: 7, id_user: 1, aktivitas: "Updated subscription for F 9101 GHI.", waktu_aktivitas: new Date(now.getTime() - 10 * 60 * 1000).toISOString() },
    { id_log: 8, id_user: 4, aktivitas: "Performed a force checkout on vehicle B 9876 BOX. Reason: Management decision.", waktu_aktivitas: new Date(now.getTime() - 5 * 60 * 1000).toISOString() }
];
