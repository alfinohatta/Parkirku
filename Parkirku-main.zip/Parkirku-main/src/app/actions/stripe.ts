'use server';

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

/**
 * Membuat PaymentIntent untuk pembayaran parkir.
 * @param amount Jumlah biaya dalam rupiah.
 * @returns Object berisi clientSecret.
 */
export async function createPaymentIntent(amount: number) {
  try {
    // Stripe mengharapkan nilai dalam satuan terkecil (cents).
    // Untuk IDR, Rp 1 = 100 units dalam API Stripe agar dianggap sebagai 1.00 IDR.
    // Jika mengirim 13000 tanpa dikali 100, Stripe menganggapnya Rp 130,00 (di bawah batas minimum 50 cents USD).
    const stripeAmount = Math.round(amount * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: stripeAmount,
      currency: 'idr',
      payment_method_types: ['card'],
      description: 'Parking fee payment for ParkRight',
    });

    return {
      clientSecret: paymentIntent.client_secret,
    };
  } catch (error: any) {
    console.error('Error creating PaymentIntent:', error);
    throw new Error(error.message);
  }
}
