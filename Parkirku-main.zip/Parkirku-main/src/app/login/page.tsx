'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import type { User } from '@/lib/types';
import { Eye, EyeOff, Car, ShieldCheck, Lock } from 'lucide-react';
import { mockUsers } from '@/lib/data';

const loginSchema = z.object({
  username: z.string().min(1, { message: 'Username is required.' }).max(20, { message: 'Username cannot exceed 20 characters.' }),
  password: z.string().min(1, { message: 'Password is required.' }).max(20, { message: 'Password cannot exceed 20 characters.' }),
});

export default function LoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);
  const [availableUsers, setAvailableUsers] = useState<User[]>([]);

  useEffect(() => {
    const storedUsers = localStorage.getItem('users');
    if (storedUsers) {
      try {
        setAvailableUsers(JSON.parse(storedUsers));
      } catch (e) {
        setAvailableUsers(mockUsers);
      }
    } else {
      setAvailableUsers(mockUsers);
      localStorage.setItem('users', JSON.stringify(mockUsers));
    }
  }, []);

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const handleLogin = (values: z.infer<typeof loginSchema>) => {
    const user = availableUsers.find(
      (u) => u.username === values.username && u.password_hash === values.password
    );

    if (user) {
      if (user.status_aktif === false) {
        toast({
          variant: 'destructive',
          title: 'Account Inactive',
          description: 'Your account has been deactivated. Please contact an admin.',
        });
        return;
      }

      localStorage.setItem('currentUser', JSON.stringify(user));
      toast({
        title: 'Access Granted',
        description: `Welcome, ${user.nama_lengkap}. Secure session initialized.`,
      });
      router.push('/');
    } else {
      toast({
        variant: 'destructive',
        title: 'Authentication Failed',
        description: 'Invalid credentials provided.',
      });
      form.setError('root', { message: 'Invalid credentials.' });
    }
  };

  return (
    <div className="relative min-h-[calc(100vh-8rem)] flex items-center justify-center overflow-hidden bg-background px-4">
      {/* Sophisticated Structured Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-5%] w-[50%] h-[50%] bg-primary/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-5%] w-[40%] h-[40%] bg-secondary/10 blur-[100px] rounded-full" />
        
        {/* Subtle Geometric Overlay */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none" 
             style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }}>
        </div>
      </div>
      
      <Card className="w-full max-w-md shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-border glass-card relative z-10 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-primary" />
        <CardHeader className="text-center pt-10 pb-4">
          <div className="mx-auto w-16 h-16 bg-foreground rounded-2xl flex items-center justify-center shadow-lg mb-6 transform -rotate-3">
            <Car className="h-9 w-9 text-background" />
          </div>
          <CardTitle className="text-3xl font-black tracking-tight text-foreground uppercase">
            Park<span className="text-primary">Right</span>
          </CardTitle>
          <CardDescription className="text-sm font-bold text-muted-foreground uppercase tracking-[0.2em] pt-1">
            Secure Management Portal
          </CardDescription>
        </CardHeader>
        <CardContent className="px-8 pb-10">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleLogin)} className="space-y-6">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Identity</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Username" 
                        {...field} 
                        maxLength={20} 
                        className="h-12 border-border bg-background focus:ring-1 focus:ring-primary transition-all rounded-lg font-semibold"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Security Key</FormLabel>
                    <div className="relative">
                      <FormControl>
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          {...field}
                          maxLength={20}
                          className="h-12 border-border bg-background focus:ring-1 focus:ring-primary transition-all rounded-lg pr-12 font-semibold"
                        />
                      </FormControl>
                      <button
                        type="button"
                        onClick={() => setShowPassword((prev) => !prev)}
                        className="absolute inset-y-0 right-0 flex items-center justify-center w-12 h-full text-muted-foreground hover:text-foreground transition-colors"
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full h-12 text-sm font-black uppercase tracking-widest bg-foreground hover:bg-foreground/90 text-background rounded-lg transition-all shadow-md group">
                <Lock className="mr-2 h-4 w-4" />
                Authenticate
              </Button>
            </form>
          </Form>
          
          <div className="mt-8 flex items-center justify-center gap-2 text-[9px] font-black text-muted-foreground/50 uppercase tracking-[0.3em]">
            <ShieldCheck className="h-3 w-3" />
            <span>Encrypted Infrastructure</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}