"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import type { User } from '@/lib/types';
import AdminDashboard from '@/components/dashboard/admin-dashboard';
import PetugasDashboard from '@/components/dashboard/petugas-dashboard';
import OwnerDashboard from '@/components/dashboard/owner-dashboard';
import { Skeleton } from '@/components/ui/skeleton';

export default function Home() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const userJson = localStorage.getItem('currentUser');
    if (!userJson) {
      router.push('/login');
    } else {
      try {
        const user = JSON.parse(userJson) as User;
        // A simple validation to ensure the object has a role property
        if (user && user.role) {
          setCurrentUser(user);
        } else {
          throw new Error("Invalid user object");
        }
      } catch (e) {
        console.error("Failed to parse user from localStorage", e);
        localStorage.removeItem('currentUser');
        router.push('/login');
      } finally {
        setLoading(false);
      }
    }
  }, [router]);
  
  if (loading) {
     return (
        <div className="container mx-auto px-4 py-8 space-y-6">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Skeleton className="h-28 rounded-lg" />
                <Skeleton className="h-28 rounded-lg" />
                <Skeleton className="h-28 rounded-lg" />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
                 <Skeleton className="h-80 rounded-lg" />
                 <Skeleton className="h-80 rounded-lg" />
            </div>
            <Skeleton className="h-[500px] w-full rounded-lg" />
        </div>
     );
  }
  
  if (!currentUser) {
    return null; // Return null while redirecting
  }

  const renderDashboard = () => {
    switch (currentUser.role) {
      case 'Admin':
        return <AdminDashboard currentUser={currentUser} />;
      case 'Petugas':
        return <PetugasDashboard currentUser={currentUser} />;
      case 'Owner':
        return <OwnerDashboard currentUser={currentUser} />;
      default:
        // This will trigger the useEffect to redirect on the next render
        localStorage.removeItem('currentUser'); 
        return <p>Invalid role. Redirecting to login...</p>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {renderDashboard()}
    </div>
  );
}
